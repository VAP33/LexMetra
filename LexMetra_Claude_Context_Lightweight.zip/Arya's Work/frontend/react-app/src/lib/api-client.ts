// Real backend integration. Replaces the mock-services.ts this demo shipped
// with. Every function here does a real network call — there is no
// simulated latency or fabricated data left in this file.
//
// Base URL is configurable via VITE_API_BASE_URL (Vite exposes import.meta.env
// at build time); defaults to the local dev backend from SETUP.md.
import type { ScanDetails } from "./types";

const API_BASE: string =
  (typeof import.meta !== "undefined" &&
    (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_API_BASE_URL) ||
  "http://localhost:8000";

const TOKEN_STORAGE_KEY = "lmpc_access_token";
const USER_STORAGE_KEY = "lmpc_user";

export class ApiError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

// ---------------------------------------------------------------------------
// Auth — every other endpoint in this backend requires a Bearer token
// (Depends(auth.require_inspector) or stricter). This was NOT true of the
// backend this file was originally built against — confirmed by reading the
// current main.py, every route except /health now requires auth.
// ---------------------------------------------------------------------------

export interface AuthedUser {
  username: string;
  role: "inspector" | "reviewer" | "admin";
}

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function getStoredUser(): AuthedUser | null {
  const raw = localStorage.getItem(USER_STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AuthedUser;
  } catch {
    return null;
  }
}

export function clearSession(): void {
  localStorage.removeItem(TOKEN_STORAGE_KEY);
  localStorage.removeItem(USER_STORAGE_KEY);
}

/** POST /auth/login uses FastAPI's OAuth2PasswordRequestForm — that's a real
 * constraint of the current backend, not a stylistic choice: it requires
 * application/x-www-form-urlencoded with fields named exactly "username"
 * and "password", not JSON. */
export async function login(username: string, password: string): Promise<AuthedUser> {
  const body = new URLSearchParams();
  body.set("username", username);
  body.set("password", password);
  let response: Response;
  try {
    response = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
  } catch {
    throw new ApiError("Could not reach the inspection service. Check your connection.");
  }
  if (!response.ok) {
    if (response.status === 401) throw new ApiError("Incorrect username or password.", 401);
    throw new ApiError(`Login failed (${response.status})`, response.status);
  }
  const data = (await response.json()) as { access_token: string; role: AuthedUser["role"]; username: string };
  localStorage.setItem(TOKEN_STORAGE_KEY, data.access_token);
  const user: AuthedUser = { username: data.username, role: data.role };
  localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
  return user;
}

/** POST /auth/register — the backend's own bootstrap rule: the very first
 * registration on a fresh database is unauthenticated and becomes admin;
 * every registration after that needs an authenticated admin calling
 * /auth/register/admin instead. This function only covers the plain
 * self-register path (fine for the first user / a demo reset). */
export async function register(username: string, password: string, role: AuthedUser["role"] = "inspector"): Promise<void> {
  await request("/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, role }),
  });
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(init?.headers);
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, { ...init, headers });
  } catch {
    // Network failure (backend down, CORS, offline) — distinct from a real
    // HTTP error status, because the UI should offer different guidance
    // ("check your connection" vs "something went wrong on our end").
    throw new ApiError(
      "Could not reach the inspection service. Check your connection or try again.",
    );
  }
  if (response.status === 401) {
    clearSession();
    throw new ApiError("Your session has expired. Please sign in again.", 401);
  }
  if (!response.ok) {
    let detail = "";
    try {
      const body = await response.json();
      detail = typeof body?.detail === "string" ? body.detail : JSON.stringify(body);
    } catch {
      /* response wasn't JSON — fall through with empty detail */
    }
    throw new ApiError(detail || `Request failed (${response.status})`, response.status);
  }
  return (await response.json()) as T;
}

/** Every member of backend/schema.py's CanonicalStatus enum. All eight, in the
 * same order. The UI previously declared only five, and TWO of those five
 * ("ABSENT", "UNOBSERVED") are not emitted by the backend at all — they were
 * invented here. The practical effect was that NON_COMPLIANT (a real statutory
 * violation), PARTIALLY_DETECTED, NOT_DETECTED_IN_PROVIDED_IMAGES and
 * INSUFFICIENT_EVIDENCE all fell through mapCanonicalStatus's `default` branch
 * and rendered identically as "Review". A violation and an unphotographed
 * panel are opposite findings; collapsing them is not acceptable in
 * enforcement software. Keep this list in sync with schema.py by hand. */
export type RawCanonicalStatus =
  | "VERIFIED"
  | "NEEDS_REVIEW"
  | "ABSENT"
  | "NOT_ASSESSABLE"
  | "NOT_APPLICABLE"
  | "NOT_DETECTED_IN_PROVIDED_IMAGES"
  | "INSUFFICIENT_EVIDENCE"
  | "PARTIALLY_DETECTED"
  | "DETECTED"
  | "NON_COMPLIANT"
  | "REVIEW_REQUIRED";

export interface RawValidationDetails {
  present?: boolean | null;
  readable?: boolean | null;
  correct_format?: boolean | null;
  compliant?: boolean | null;
}

/**
 * The ACTUAL JSON shape of backend/schema.py's CanonicalDeclaration.
 *
 * This interface previously described a contract that never existed on the
 * wire. CanonicalDeclaration exposes `canonical_field`, `extracted_value`,
 * `label_present`, `value_present`, `provenance`, `statutory_rule` and
 * `rule_description` as plain Python `@property` accessors — and Pydantic
 * serializes DECLARED FIELDS ONLY, never properties (nothing in the backend
 * uses `@computed_field`). So none of those seven keys are present in the
 * response body. Reading them yielded `undefined` on every row, which is why
 * the UI rendered "Unknown" for every field name and had no provenance/rule
 * details to show.
 *
 * `rule_clause` is the declared field that holds the clause string (e.g.
 * "Rule 6(1)(a)/(b)/(c)"), falling back to `rule_id`.
 */
export interface RawCanonicalDeclaration {
  field: string;
  canonical_name: string;
  label?: string | null;
  value?: string | null;
  normalized_value?: unknown;
  raw_text?: string | null;
  confidence?: number;
  ocr_confidence?: number | null;
  extraction_confidence?: number | null;
  evidence_confidence?: number | null;
  status: RawCanonicalStatus;
  evidence?: {
    image_id?: string | null;
    page_or_view?: string | null;
    bbox?: number[] | null;
    source?: string | null;
  } | null;
  validation?: RawValidationDetails | null;
  reason?: string | null;
  rule_id?: string | null;
  rule_clause?: string | null;
  // The specific rule VERSION actually used for this declaration (e.g.
  // "2011"), from the active rule's own metadata. Absent when the row is
  // NOT_APPLICABLE because its governing rule is not currently active.
  rule_version?: string | null;
}

export interface RawDeclarationSummary {
  applicable: number;
  assessed?: number;
  detected: number;
  verified: number;
  needs_review?: number;
  review_required: number;
  absent?: number;
  non_compliant: number;
  not_assessable?: number;
  not_applicable?: number;
}

/** Raw shape returned by POST /scan — see backend/main.py. */
export interface RawScanResponse {
  inspection: {
    inspection_id: string;
    product_category: string;
    sale_type: string;
    overall_status: "PASS" | "FAIL" | "UNCERTAIN" | "EXEMPT";
    exempt_reason?: string | null;
    disclaimer: string;
    review_required?: boolean;
    facts: Array<{
      field: string;
      extracted_value: string | null;
      status: "PASS" | "FAIL" | "UNCERTAIN" | "EXEMPT";
      confidence: number;
      rule_id?: string | null;
      rule_version?: string | null;
      reason: string;
      review_required: boolean;
      bbox?: { x: number; y: number; width: number; height: number } | null;
      // Named inputs the rule engine needed but never received. Populated by
      // backend/rule_engine.py (e.g. ["calibrated_pdp_area_cm2"] when Rule 7(2)
      // font-height could not select a threshold). Already serialized by the
      // backend; the UI uses it to tell "we looked and judged" apart from
      // "we could not look because an input is missing".
      missing_evidence?: string[];
    }>;
    declarations?: RawCanonicalDeclaration[];
    declaration_summary?: RawDeclarationSummary;
  };
  raw_ocr_fields?: Record<string, { value?: string; confidence?: number }>;
  resolved_inputs?: {
    mrp?: number | null;
    mrp_source?: string;
    net_quantity_value?: number | null;
    net_quantity_unit?: string | null;
    net_quantity_source?: string;
    pdp_area_cm2?: number | null;
  };
  barcode_info?: {
    status: string;
    symbol_count: number;
    primary_gtin?: string | null;
    primary_symbology?: string | null;
    primary_method?: string | null;
  } | null;
  sticker_suspects?: Array<{ bbox: [number, number, number, number]; confidence: number; reason: string }>;
  nearest_matches?: Array<{ product_id: string; image_id: string; score: number }>;
  price_or_label_change_flag?: string | null;
}

/** Raw shape returned by GET /inspections and /inspections/{id}. */
export interface RawInspectionRow {
  inspection_id: string;
  product_id?: string | null;
  sale_type: string;
  product_category: string;
  net_quantity_value?: number | null;
  net_quantity_unit?: string | null;
  mrp?: number | null;
  overall_status: "PASS" | "FAIL" | "UNCERTAIN" | "EXEMPT";
  exempt_reason?: string | null;
  image_filename?: string | null;
  created_at: string;
  reviewed: boolean;
  reviewer_note?: string | null;
  review_required?: boolean;
  facts?: RawScanResponse["inspection"]["facts"];
  declarations?: RawCanonicalDeclaration[];
  declaration_summary?: RawDeclarationSummary;
}

export async function scanPackage(file: Blob, details: ScanDetails): Promise<RawScanResponse> {
  const form = new FormData();
  form.append("file", file, "capture.jpg");
  form.append("product_id", details.productId);
  form.append("sale_type", details.saleType);
  form.append("product_category", details.productCategory);
  if (details.netQuantityValue !== undefined) form.append("net_quantity_value", String(details.netQuantityValue));
  if (details.netQuantityUnit) form.append("net_quantity_unit", details.netQuantityUnit);
  if (details.mrp !== undefined) form.append("mrp", String(details.mrp));
  if (details.pdpAreaCm2 !== undefined) form.append("pdp_area_cm2", String(details.pdpAreaCm2));
  if (details.isExportOnly) form.append("is_export_only", "true");
  if (details.retailBundleCount !== undefined) form.append("retail_bundle_count", String(details.retailBundleCount));
  if (details.isImported !== undefined) form.append("is_imported", String(details.isImported));
  return request<RawScanResponse>("/scan", { method: "POST", body: form });
}

export interface ExtractPreviewResponse {
  status: string;
  images: Array<{
    index: number;
    image_id: string;
    width: number;
    height: number;
    lines_detected: number;
  }>;
  total_lines: number;
  suggested_details: {
    product_id: string;
    product_id_source?: string;
    needs_manual_entry?: boolean;
    barcode_needs_confirmation?: boolean;
    barcode_info?: {
      status: string;
      symbol_count: number;
      primary_gtin?: string | null;
      primary_symbology?: string | null;
      primary_method?: string | null;
      notes?: string[];
    } | null;
    sale_type: "retail" | "wholesale" | "industrial" | "institutional";
    category: string;
    net_quantity_value: number | null;
    net_quantity_unit: string;
    mrp: number | null;
    pdp_area_cm2?: number | null;
  };
  field_extractions: Record<
    string,
    {
      value?: string | null;
      confidence: number;
      source_image?: string | null;
      detected: boolean;
    }
  >;
  raw_ocr_fields: Record<string, any>;
}

/**
 * Lightweight OCR extraction preview for the capture -> confirm flow.
 * Runs OCR across surfaces to pre-fill the confirmation form and give the inspector
 * immediate feedback on detected declarations before the full legal compliance check.
 */
export async function extractPreview(images: Blob[]): Promise<ExtractPreviewResponse> {
  const form = new FormData();
  if (images.length === 1) {
    form.append("file", images[0], "surface_1.jpg");
  } else {
    images.forEach((img, idx) => {
      form.append("files", img, `surface_${idx + 1}.jpg`);
    });
  }
  return request<ExtractPreviewResponse>("/extract-preview", {
    method: "POST",
    body: form,
  });
}


// ---------------------------------------------------------------------------
// Multi-surface inspection sessions — the real way to capture more than one
// photo of a package. My earlier version of this file captured multiple
// photos in the UI but only ever sent the first one to /scan, discarding
// the rest as inert "supplementary evidence" — that was a real, disclosed
// limitation at the time because no multi-surface endpoint existed yet.
// It exists now (confirmed by reading the current backend), so this
// replaces that workaround with the real thing: open a session, POST each
// captured photo as its own surface, then finalize once to get one
// inspection built from the UNION of all surfaces.
// ---------------------------------------------------------------------------

export interface CreateSessionRequest {
  productId: string;
  saleType: string;
  productCategory: string;
  netQuantityValue?: number;
  netQuantityUnit?: string;
  mrp?: number;
  pdpAreaCm2?: number;
  isExportOnly?: boolean;
  retailBundleCount?: number;
  isImported?: boolean;
}

export interface CreateSessionResponse {
  session_id: string;
  status: string;
  coverage: number;
  missing_fields: string[];
  guidance: string[];
}

export async function createSession(req: CreateSessionRequest): Promise<CreateSessionResponse> {
  return request<CreateSessionResponse>("/sessions", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      product_id: req.productId,
      sale_type: req.saleType,
      product_category: req.productCategory,
      ...(req.netQuantityValue !== undefined ? { net_quantity_value: req.netQuantityValue } : {}),
      ...(req.netQuantityUnit ? { net_quantity_unit: req.netQuantityUnit } : {}),
      mrp: req.mrp,
      pdp_area_cm2: req.pdpAreaCm2,
      is_export_only: req.isExportOnly ?? false,
      retail_bundle_count: req.retailBundleCount,
      is_imported: req.isImported,
    }),
  });
}

export interface AddCaptureResponse {
  session_id: string;
  surface_id: string;
  image_quality: { status: string; notes?: string[] };
  cumulative_coverage: number;
  missing_fields: string[];
  evidence_sufficient: boolean;
  guidance: string[];
  total_captures: number;
}

export type SurfaceType = "FRONT" | "BACK" | "SIDE" | "LABEL" | "TOP" | "BOTTOM" | "UNKNOWN";

export async function addSessionCapture(
  sessionId: string,
  file: Blob,
  surfaceType?: SurfaceType,
): Promise<AddCaptureResponse> {
  const form = new FormData();
  form.append("file", file, "capture.jpg");
  if (surfaceType) form.append("surface_type", surfaceType);
  return request<AddCaptureResponse>(`/sessions/${encodeURIComponent(sessionId)}/captures`, {
    method: "POST",
    body: form,
  });
}

export interface SessionStatusResponse {
  session: { session_id: string; status: string };
  captures: Array<{ surface_id: string; surface_type: string; evidence_coverage: number; created_at: string }>;
  cumulative_coverage: number;
  missing_fields: string[];
  evidence_sufficient: boolean;
}

export async function getSessionStatus(sessionId: string): Promise<SessionStatusResponse> {
  return request<SessionStatusResponse>(`/sessions/${encodeURIComponent(sessionId)}`);
}

/** Returns the same shape as /inspect — a raw ProductInspection, not the
 * richer /scan envelope (no sticker_suspects/nearest_matches at this call
 * site in the current backend). Adapt with fromInspectionRow-style handling. */
export async function finalizeSession(sessionId: string): Promise<RawScanResponse["inspection"]> {
  return request(`/sessions/${encodeURIComponent(sessionId)}/finalize`, { method: "POST" });
}

export async function listInspections(params?: {
  limit?: number;
  status?: string;
  needsReview?: boolean;
}): Promise<RawInspectionRow[]> {
  const query = new URLSearchParams();
  if (params?.limit) query.set("limit", String(params.limit));
  if (params?.status) query.set("status", params.status);
  if (params?.needsReview) query.set("needs_review", "true");
  const qs = query.toString();
  return request<RawInspectionRow[]>(`/inspections${qs ? `?${qs}` : ""}`);
}

export async function getInspectionDetail(id: string): Promise<RawInspectionRow> {
  return request<RawInspectionRow>(`/inspections/${encodeURIComponent(id)}`);
}

export async function markReviewed(id: string, note: string): Promise<void> {
  await request(`/inspections/${encodeURIComponent(id)}/review`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ note }),
  });
}

export async function getProductHistory(
  productId: string,
): Promise<Array<{ inspection_id: string; overall_status: string; mrp: number | null; created_at: string }>> {
  return request(`/products/${encodeURIComponent(productId)}/history`);
}

export async function checkHealth(): Promise<{ status: string } | null> {
  try {
    return await request<{ status: string }>("/health");
  } catch {
    return null;
  }
}

/**
 * PDF report download. The generation endpoint may not exist yet depending
 * on which backend workstream has landed — this checks availability with a
 * HEAD request first rather than opening a tab to a 404, so the UI can show
 * a clear "not available yet" state instead of a broken download.
 */
export async function reportPdfAvailable(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/inspections/${encodeURIComponent(id)}/report.pdf`, {
      method: "HEAD",
    });
    return res.ok;
  } catch {
    return false;
  }
}

export function reportPdfUrl(id: string): string {
  return `${API_BASE}/inspections/${encodeURIComponent(id)}/report.pdf`;
}

// ---------------------------------------------------------------------------
// Regulation ingestion (Module 1 integration)
// ---------------------------------------------------------------------------

export interface RuleVersionDraft {
  id: string;
  module: string;
  regulation: string;
  rule_id: string;
  version: string;
  effective_from: string;
  effective_to?: string | null;
  approval_state: string;
  text?: string | null;
  thresholds?: Array<Record<string, unknown>>;
}

export interface AmendmentChangeDraft {
  rule_id: string;
  change_type: string;
  old_text?: string | null;
  new_text?: string | null;
  effective_from?: string | null;
}

export interface AmendmentDraft {
  id: string;
  module: string;
  source_document_id: string;
  approval_state: string;
  extracted_at: string;
  changes: AmendmentChangeDraft[];
  proposed_rule_versions: RuleVersionDraft[];
  impact: Record<string, unknown>;
}

export interface IngestRegulationResponse {
  draft: AmendmentDraft;
  page_count: number;
  rule_count: number;
  rejected_count: number;
  needs_review_count: number;
}

/** Upload a regulation PDF and run it through OCR/extraction. Produces a
 * new AmendmentDraft (approval_state "EXTRACTED") for human review -- it
 * never itself changes current compliance evaluation. */
export async function ingestRegulation(
  file: Blob,
  filename: string,
  options?: { regulation?: string; module?: string; version?: string; forceOcr?: boolean },
): Promise<IngestRegulationResponse> {
  const form = new FormData();
  form.append("file", file, filename);
  if (options?.regulation) form.append("regulation", options.regulation);
  if (options?.module) form.append("module", options.module);
  if (options?.version) form.append("version", options.version);
  if (options?.forceOcr) form.append("force_ocr", "true");
  return request<IngestRegulationResponse>("/regulations/ingest", { method: "POST", body: form });
}

export async function listAmendmentDrafts(approvalState?: string): Promise<AmendmentDraft[]> {
  const qs = approvalState ? `?approval_state=${encodeURIComponent(approvalState)}` : "";
  const res = await request<{ drafts: AmendmentDraft[] }>(`/regulations/drafts${qs}`);
  return res.drafts;
}

export async function getAmendmentDraft(id: string): Promise<AmendmentDraft> {
  return request<AmendmentDraft>(`/regulations/drafts/${encodeURIComponent(id)}`);
}

export async function transitionAmendmentDraft(
  id: string,
  targetState: string,
  reviewer?: string,
): Promise<AmendmentDraft> {
  return request<AmendmentDraft>(`/regulations/drafts/${encodeURIComponent(id)}/transition`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ target_state: targetState, reviewer }),
  });
}

export interface RuleIdentifiedItem {
  rule_id: string;
  display_provision: string;
  amendment_target?: string | null;
  amendment_item?: string | null;
  amendment_operation?: string | null;
  canonical_english_text: string;
  rule_type: string;
  parent_regulation: string;
  amendment_version: string;
  effective_from: string;
  effective_to?: string | null;
  applicability: {
    manufactured_packed_imported_after?: string;
    duration?: string;
    scope?: string;
    [key: string]: any;
  };
  source_provision?: string;
  source_languages?: string[];
  status: string;
  evidence_requirements?: any[];
  metadata_sources?: Record<string, any>;
}

export interface ContextProvisionItem {
  provision: string;
  type: string;
  purpose: string;
  is_executable: boolean;
  effective_from?: string | null;
  title?: string;
  version?: string;
  source?: string;
}

export interface RulesIdentifiedResponse {
  draft_id: string;
  source_document_id?: string;
  approval_state: string;
  rules_identified_count: number;
  rules_identified: RuleIdentifiedItem[];
  context_provisions_count: number;
  context_provisions: ContextProvisionItem[];
  amendment_metadata: Record<string, any>;
  raw_extraction: Record<string, any>;
}

export interface EvaluatedRuleItem {
  rule: string;
  rule_id: string;
  status: "CONSIDERED / APPLICABLE" | "NOT_APPLICABLE" | "EXEMPT" | "SUPERSEDED" | "UNCERTAIN";
  reason: string;
  applicability_condition?: Record<string, any>;
  evidence_used?: Record<string, any>;
}

export interface ApplicabilityEvaluationResponse {
  draft_id: string;
  product_context: Record<string, any>;
  rules_considered_count: number;
  rules_considered: EvaluatedRuleItem[];
  rules_not_considered_count: number;
  rules_not_considered: EvaluatedRuleItem[];
}

export interface PublishReceipt {
  draft_id: string;
  amendment_id: string;
  amendment: string;
  module_id: string;
  parent_rule_set: string;
  parent_regulation: string;
  status: string;
  rules_published_count: number;
  rules_published: string[];
  published_rules: Array<{
    rule_id: string;
    display_provision: string;
    version: string;
    effective_from: string;
    applicability: Record<string, any>;
  }>;
  effective_from: string;
  published_at: string;
  published_by: string;
}

export interface ActiveRuleItem {
  rule_version_id: string;
  module_id: string;
  parent_regulation: string;
  rule_id: string;
  version: string;
  effective_from: string;
  effective_to?: string | null;
  approval_state: string;
  source_document_id?: string;
  source_url?: string;
  text: string;
  conditions: Record<string, any>;
  thresholds: any[];
  evidence_requirements: any[];
  created_at: string;
}

export interface ActiveRulesResponse {
  module: string;
  parent_regulation: string;
  active_rules_count: number;
  active_rules: ActiveRuleItem[];
}

export interface DatabaseVerificationResponse {
  draft_id: string;
  regulation_id: string;
  parent_regulation: string;
  rule_set_id: string;
  amendment_id: string;
  draft_approval_state: string;
  published_in_regulatory_amendments: boolean;
  amendment_record?: Record<string, any> | null;
  rule_versions_count: number;
  rule_versions: any[];
  provenance_chain: string;
}

export async function getRulesIdentified(draftId: string): Promise<RulesIdentifiedResponse> {
  return request<RulesIdentifiedResponse>(`/regulations/drafts/${encodeURIComponent(draftId)}/rules-identified`);
}

export async function evaluateApplicability(
  draftId: string,
  context?: { product_category?: string; manufacture_date?: string; is_imported?: boolean },
): Promise<ApplicabilityEvaluationResponse> {
  return request<ApplicabilityEvaluationResponse>(`/regulations/drafts/${encodeURIComponent(draftId)}/evaluate-applicability`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(context || {}),
  });
}

export async function publishAmendmentDraft(id: string): Promise<PublishReceipt> {
  return request<PublishReceipt>(`/regulations/drafts/${encodeURIComponent(id)}/publish`, {
    method: "POST",
  });
}

export async function getActiveRules(module: string = "lmpc", asOf?: string): Promise<ActiveRulesResponse> {
  const qs = asOf ? `?module=${encodeURIComponent(module)}&as_of=${encodeURIComponent(asOf)}` : `?module=${encodeURIComponent(module)}`;
  return request<ActiveRulesResponse>(`/regulations/active-rules${qs}`);
}

export async function getDatabaseVerification(draftId: string): Promise<DatabaseVerificationResponse> {
  return request<DatabaseVerificationResponse>(`/regulations/verification/${encodeURIComponent(draftId)}`);
}

