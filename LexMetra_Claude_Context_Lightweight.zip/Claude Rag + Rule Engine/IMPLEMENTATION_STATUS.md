# IMPLEMENTATION_STATUS.md
## SIH 2026 — PS 26034 — Legal Metrology Compliance Platform
### Execution log (persistent — read this + PROJECT_STATE.md before resuming work)

This file is a chronological work log. `PROJECT_STATE.md` is the current
high-level snapshot. If they ever disagree, trust the repository itself
first, this log second (it records *why*, not just *what*).

---

## Session 1 — Backend hardening pass

Started from a pre-existing, honest, read-only audit (`PROJECT_STATE.md`,
Sept 2026, ~35% complete / pre-alpha). Followed its own P0→P1→P2 roadmap
rather than re-deriving one.

### Completed

1. **P0 fixes**
   - Added missing `pytesseract`, `python-dotenv`, `python-jose[cryptography]`,
     `passlib[bcrypt]`, `bcrypt`, `reportlab`, `pytest`, `pytest-cov` to
     `backend/requirements.txt`. Documented the Tesseract *binary* (non-pip)
     dependency inline.
   - Confirmed `ocr_extraction.run_ocr()` already degrades gracefully
     (per-call `try/except`) if the Tesseract binary is absent — this
     specific claim in the prior audit was verified true, not just assumed.
   - Moved `DATABASE_URL` out of source into `backend/config.py`
     (env-var driven, `.env` support via `python-dotenv`). Added
     `backend/.env.example`. `config.py` refuses to start with the
     placeholder JWT secret unless `LMPC_DEV_MODE=true`.

2. **Authentication & RBAC (new)**
   - `backend/auth.py`: bcrypt password hashing, JWT issuing/verification,
     three-tier role hierarchy (`inspector` < `reviewer` < `admin`),
     FastAPI dependencies (`require_inspector`, `require_reviewer`,
     `require_admin`).
   - `db/schema.sql`: new `users` table. Bootstrap rule — the very first
     `/auth/register` call on a fresh DB is allowed unauthenticated and is
     granted `admin`; every subsequent registration requires an
     authenticated admin via `/auth/register/admin`.
   - All write/read endpoints (`/scan`, `/inspect`, `/analyze-image`,
     `/inspections*`, `/products/*/history`, `/sessions*`) now require at
     least `inspector`. `/inspections/{id}/review` requires `reviewer`.
     `/audit-log` requires `admin`.
   - CORS origins now read from `config.ALLOWED_ORIGINS` (was `["*"]`).

3. **Audit trail (new)**
   - `db/schema.sql`: `audit_log` table (append-only). `db.record_audit_event()`
     never raises — audit logging cannot break the inspection pipeline.
   - Logged: login success/failure, user creation, inspection creation
     (via `/scan`, `/inspect`, and session finalize), review actions,
     report generation, session creation/capture/finalization.
   - `inspections.created_by` / `.reviewed_by` / `.image_path` columns added
     (idempotent `ALTER TABLE ... IF NOT EXISTS` migration block).

4. **Evidence retention (new)**
   - `/scan` and session captures now write the original uploaded image to
     `config.UPLOAD_DIR` under a UUID-prefixed filename (prevents path
     traversal / collision from a client-supplied filename) and store the
     path against the inspection record. Previously images were processed
     and discarded — a real legal-evidence gap, now closed.

5. **PDF report generation (new)**
   - `backend/report.py` (reportlab, not WeasyPrint — avoids native-dep
     fragility). `GET /inspections/{id}/report.pdf`. Renders the mandatory
     disclaimer ("automated screening / pre-inspection aid, not a final
     legal determination"), summary table, and a findings table with rule
     ID / status / reason / confidence per finding. Verified: produces a
     valid 2-page PDF against a real synthetic-dataset scan.

6. **Rule 24 (wholesale) evaluator (new)**
   - Generalized the Rule 6 declaration evaluator in `rule_engine.py` into
     `_evaluate_declaration_rule()`, reused for a new
     `_evaluate_rule24_wholesale_declarations()`, wired into `run_inspection()`
     for `sale_type == "wholesale"`. Added a new public
     `required_declaration_fields()` helper (used later by the capture-
     session coverage math). Verified via `/inspect` with a wholesale
     payload: Rule 24 facts fire, Rule 6 facts do not.

7. **Field-name bridge fix / consolidation**
   - The OCR→rule-vocabulary bridge (`manufacturer_name` →
     `manufacturer_name_address`, `expiry_date` → `best_before_use_by`,
     `net_quantity` → `wholesale_count_or_net_quantity`) previously lived
     only in `main._prepare_extractions()` and was applied inconsistently
     (missing from `/inspect` entirely). Extracted into a single
     `capture_session.bridge_classified_fields()` and made it the *only*
     place this mapping is defined; both `main._prepare_extractions()` and
     the new capture-session coverage math now call it. Applied the bridge
     to `/inspect` for the first time.

8. **Conservative applicability inference (new)**
   - `main._infer_applicability_context()`: `best_before_applicable` now
     inferred from a perishable-category allowlist (food/beverage/dairy/
     bakery/confectionery); `is_imported` inferred only from an explicit
     caller flag or a *positively extracted* non-India country-of-origin
     OCR value — absence of that field is never treated as "not imported"
     (would silently skip the very check meant to catch undeclared
     imports). Both flags previously defaulted to `False` unconditionally.

9. **Multi-surface capture sessions (new — the core architectural gap
   identified in the original audit, section 1.5 "Multi-surface / multi-image
   session stitching: schema supports it; no capture orchestration")**
   - `backend/capture_session.py`: merges per-capture OCR fields across a
     session (keeps the higher-confidence reading per field on conflict),
     computes real evidence coverage using the exact same
     `required_declaration_fields()` the legal engine uses, generates
     human capture guidance ("Capture the panel showing the MRP",
     "Evidence sufficient for applicable checks", etc.).
   - `backend/image_quality.py`: classical-CV (Laplacian blur, exposure,
     highlight-clipping glare) image-quality assessment, and a heuristic
     PDP bounding-box estimate from OCR text clustering (explicitly
     informational, never fed into the font-height legal check, which
     still requires a separately-calibrated `pdp_area_cm2`).
   - `db/schema.sql`: `inspection_sessions` + `session_captures` tables.
   - New endpoints: `POST /sessions`, `POST /sessions/{id}/captures`,
     `GET /sessions/{id}`, `POST /sessions/{id}/finalize`.
   - **Two real bugs found and fixed during live testing (not just written
     — actually exercised against a running Postgres instance):**
     a. Coverage math was checking raw OCR field names instead of bridged
        rule-vocabulary names (see item 7) — a present declaration would
        be reported as permanently "missing" to the inspector. Fixed by
        the bridge consolidation above.
     b. **JSONB double-decode bug**: `session_captures.ocr_fields_json` /
        `surface_observation_json` (and the pre-existing
        `inspection_facts.evidence_json`) are `JSONB` columns; psycopg2
        auto-decodes these to native Python objects on read. The original
        code (both the new session-read path AND the pre-existing
        `get_inspection_detail()` evidence decode, which predates this
        session) called `json.loads()` on the already-decoded object,
        raised `TypeError`, silently caught it, and reset the value to
        `{}` / `None`. This meant every persisted fact's `evidence` field
        was silently `None`, and session coverage silently reset to `0.0`
        on any read-back. Fixed both call sites to handle either a raw
        JSON string or an already-decoded object.
   - Verified end-to-end after the fix: create session, one capture reaches
     75% coverage, guidance correctly lists only genuinely-missing fields,
     `GET /sessions/{id}` read-back matches, and `finalize` produces a real
     `FAIL` for declarations confirmed absent with sufficient coverage
     (not a permanent `UNCERTAIN`), `PASS` for everything found, and
     rejects a second finalize attempt (409) and an empty-session finalize
     (400).

10. **Test suite (new — was zero test files)**
    - `backend/tests/`: `test_exemption.py`, `test_rule_engine.py`,
      `test_auth.py`, `test_capture_session.py` (unit, no DB required) and
      `test_api_integration.py` (live FastAPI `TestClient` + real Postgres).
    - `tests/conftest.py`: `db_ready` session fixture now calls
      `db.truncate_all_data()` before each test run so results never depend
      on leftover manual-testing data in the same `DATABASE_URL` — this is
      opt-out via `LMPC_TEST_RESET_DB=false`, and is documented as
      destructive/test-only. Do not point this test suite at a database
      containing real inspection records.
    - Current result: 34 passed, 0 skipped (verified live, not assumed).
    - Two test-authoring bugs were caught and fixed along the way (both in
      test assumptions, not product code): the export-exemption test needs
      `sale_type="export"`, not just `is_export_only=True` — the product
      code was already correctly conservative here (an export-marked
      package sold at retail is NOT silently exempt; Rule 25 governs that
      case) — and a pytest fixture scope mismatch.

11. **Deployment**
    - `backend/Dockerfile` (python:3.12-slim + tesseract-ocr installed via
      apt, since it's a native binary pytesseract needs), `docker-compose.yml`
      (backend + Postgres 16, healthchecked, named volumes for DB/uploads/
      reports), `.dockerignore`.
    - Not yet verified: Docker itself is not available in this sandbox
      (`docker: not found`), so the image build/compose-up has NOT been
      executed. The Dockerfile mirrors the exact manual setup (same apt
      packages, same pip requirements, same env var names) already
      validated live outside a container. Verify `docker compose up --build`
      plus `curl localhost:8000/health` on first use in an environment with
      Docker.

### Manually verified live (curl + running uvicorn + real Postgres 16 + real synthetic-dataset images), in addition to the pytest suite
- `/health`, `/auth/register` (bootstrap), `/auth/login`, `/auth/me`
- RBAC: unauthenticated `/scan` returns 401; inspector calling `/review` returns 403
- `/scan` full pipeline: OCR to field extraction to rule engine to Postgres
  persistence to evidence image saved on disk
- `/inspect` wholesale payload: Rule 24 facts fire, not Rule 6
- `/inspections`, `/inspections/{id}/report.pdf` (valid 2-page PDF)
- `/inspections/{id}/review` (reviewer role, `reviewed_by` recorded)
- `/audit-log` (admin-only, contains the actions above)
- `/sessions`, `/sessions/{id}/captures` (x2), `/sessions/{id}`,
  `/sessions/{id}/finalize` (see item 9 above)

### Known issues / accepted limitations at end of this session
- The synthetic dataset (`dataset/images/`) has one label-image per
  product covering nearly all fields, so multi-surface testing so far
  exercises "second photo of the same product" merging, not a genuine
  disjoint front/back split. Real product photos (or a purpose-built
  two-surface synthetic pair) would exercise the coverage math more
  realistically — this is a test-data gap, not a code gap.
- `vlm_verifier.py` is wired into `/scan` (`_apply_vlm_verification`) but
  gated behind `VLM_VERIFICATION_ENABLED=true` plus `ANTHROPIC_API_KEY`;
  not exercised end-to-end against a live Anthropic API in this session
  (would require a real key; `api.anthropic.com` is in the sandbox's
  allowed domain list, so this is untested rather than unsupported).
- Docker build unverified (see above).
- No mobile application, ARCore/depth integration, or offline/sync layer.
  The multi-surface backend orchestration now exists (item 9), but there
  is no guided-camera client consuming it yet.
- Rules 4, 5, 25, 26(b), 26(c), 27, 31 still have data in `rules.json` but
  no evaluator in `rule_engine.py` (unchanged from the original audit).
- Rule 7(2) font-height check still requires a manually-calibrated
  `pdp_area_cm2`; no automatic pixel-to-mm path (unchanged).
- Trained OCR layout model, trained tamper/sticker classifier, real product
  photo dataset: none added (explicitly out of scope for a code-only
  session; these need real data collection).

### Exact next actions (priority order, for whoever resumes this)
1. Verify `docker compose up --build` end-to-end in an environment with
   Docker; fix any image-build issues (most likely candidate: apt package
   names/versions on a fresh `python:3.12-slim` pull).
2. Build a genuine two-surface synthetic test fixture (front label missing
   manufacturer info, back label missing MRP, e.g.) to properly exercise
   `capture_session` coverage math with disjoint evidence per photo.
3. Wire a minimal guided-capture client (even a thin web page using
   `/sessions/*`) so the multi-surface backend has some consumer beyond
   curl — this is the natural next visible milestone before a real mobile
   app.
4. Implement Rule 25 (export repack) evaluator — currently the only
   sale-type-conditional path with zero evaluator coverage that also has a
   clear exemption-engine interaction already documented in
   `exemption.py`'s comments (see `exemption.py` lines ~299-301).
5. Decide and document a strategy for `product_similarity.py`'s flat JSON
   index (currently fine for a demo, will not scale — unchanged from
   original audit).

---

## Session 3 — Vision-layer verification and legal-core testability

> **Note on numbering:** Session 2 built the region-first OCR pipeline
> (`preprocess.py`, `region_detection.py`, `ocr_engine.py`, the `images dataset/`
> folder) and was never written up here — that session ended abruptly. Its output
> is in the repository and is covered by the tests described below. This section
> is Session 3.

This session did not add features. It closed verification gaps, and in doing
so found and fixed two real defects. Everything below was measured or executed;
nothing is asserted from inspection alone.

### Two real defects found and fixed

**1. Fusion could report two contradictory numbers as mutually confirming.**
`text_similarity("NET QUANTITY 100 g", "NET QUANTITY 700 g")` is 0.9333, above
the 0.86 agreement threshold, so two OCR passes that flatly disagreed about the
net quantity were fused as CORROBORATED **and given a confidence bonus**. One
wrong digit in a long line barely moves a character ratio. Fixed by
`numeric_signature()` / `readings_agree()` in `ocr_engine.py`: agreement now
requires both glyph similarity AND identical ordered digit runs (after
glyph-confusion canonicalisation, so `1OO` vs `100` is not a false conflict).
A numeric disagreement is now always CONFLICTING and is never resolved
automatically. Measured effect on real photographs: conflicts on dataset image 0
rose 22 → 24 while usable characters were essentially unchanged (1282 vs 1284),
i.e. it flagged two genuinely contradictory groups without costing recall.

**2. Unrecognised legal conditions silently became mandatory requirements.**
`_condition_is_applicable()` in `rule_engine.py` ended in a bare `return True`,
so any `condition` string in `rules.json` that the engine did not implement made
its requirement unconditionally applicable. `rules.json` already ships three such
strings (`pan_masala`, `tobacco_or_tobacco_product`,
`package_is_within_the_partial_relaxation_range`). Verified before fixing: a
requirement conditioned on `tobacco_or_tobacco_product` was returned as mandatory
for a package whose context said nothing about tobacco — and once package
coverage is sufficient, an absent mandatory declaration becomes **FAIL**. That is
the system accusing a compliant package of breaking the law.

To be precise about severity: this was **latent, not live**. The only one of the
three currently sitting in a `requirements` list has `field: None`, so
`_build_requirement_map` skipped it at its `if not field` guard. It was one
rules.json edit away from being live.

Fixed with a genuine tri-state, `condition_applicability()` returning
`APPLICABLE` / `NOT_APPLICABLE` / `APPLICABILITY_UNKNOWN`. Returning False
instead would merely have traded a false FAIL for a false PASS (the requirement
would be silently dropped), so neither boolean is honest. An UNKNOWN requirement
is still evaluated and still reported, but its absence can only ever produce
UNCERTAIN. Defaults are only applied where this engine's own public API
publishes one (mirroring `run_inspection()`'s keyword defaults, guarded against
drift by `test_condition_defaults_match_the_public_api`); the three conditions
with no published default are never assumed in either direction.

### One negative result, recorded in code so it is not re-attempted
De-duplicating overlapping OCR read-sets looked like a free 36% speedup
(32.6s → 21.0s on image 0). It is harmful and was reverted. Two measured
reasons, both documented at length above `select_regions_to_read()` in
`ocr_engine.py` and guarded by
`test_overlapping_reads_are_deliberately_not_deduplicated`:
- **Recall.** A small crop is preprocessed on its own terms; the same text
  inside a large panel is thresholded against panel statistics and left too
  small for Tesseract. On image 0 three prose lines read correctly from the
  contained region (conf 0.96) and as garbage from the containing region
  (conf 0.15). Image 7 lost 27% of its characters at identical wall-clock time.
  An area-ratio guard recovered images 3 and 7 but not image 0 — geometry does
  not predict which recipe reads better.
- **Evidence quality, which matters more.** Reading the same pixels under
  different recipes is the only source of CORROBORATED/CONFLICTING within a
  single image. Removing the redundancy does not remove the disagreement in the
  pixels, only our knowledge of it — the spurious `'17m'` went from CONFLICTING
  at conf 0.93 to CORROBORATED at conf 1.00. That converts an honest "sources
  disagree" into unearned confidence.

### Test suite: 171 passed, 1 collection error, 10 skipped
`test_orientation` (26, new), `test_ocr_engine` (46, new), `test_rule_engine`
(6 → 21), `test_preprocess` (35), `test_region_detection` (30),
`test_capture_session` (9), `test_exemption` (4).

`map_bbox_from_rotated` is now genuinely verified rather than assumed: all four
orientations × 24+ boxes on deliberately odd non-square dimensions, rotated
forward *by construction* (a mask containing only the box is rotated and the box
read back out of it, so the test does not depend on the arithmetic it checks),
plus a pixel-level check that the mapped box covers the same ink count.

### Performance: measured, and the remaining lever identified
~24s per dense 2392×1080 phone screenshot. cProfile on dataset image 7:
**22.62s of 26.17s is inside 14 Tesseract subprocess calls** (1.615s each), 2.24s
is the one-time `import pytesseract` (amortises to zero in a long-lived server
process), and ~1.3s covers detection, preprocessing, orientation and fusion
combined. The pipeline is ~94% Tesseract subprocess latency in steady state.

Three candidate levers were tested and two are ruled out by measurement:
read-set de-duplication (harmful, above) and `READ_TILE_MAX_SIDE_PX`. The one
remaining lever is **variant ranking quality** — `OCR_VARIANT_SLOTS` cannot drop
from 3 to 2 without losing 41% of image 3's characters, which means the best
variant is often not ranked first. Ranking better, not reading less, is where the
time is.

An earlier apparent timing regression (16.77s → 25.1s on image 7) was checked
rather than attributed: three consecutive runs gave 25.08 / 24.61 / 23.27s with
byte-identical output (14 calls, 466 chars), and the profile puts the cost in
Tesseract subprocesses, not in the new numeric check. It is host load, not the
change.

### ENVIRONMENT BLOCK — read this before trusting any test result
`fastapi`, `psycopg2`, `jose`, `passlib` and `pyzbar` are not installed in the
development container and **cannot be installed** (`pip` fails with
`ProxyError: Tunnel connection failed: 403 Forbidden`; no cached wheels, no
venvs). Consequences, stated plainly:

- **The test suite runs under two shims, not under its real dependencies.**
  `backend/tools/run_tests.py` provides a minimal pytest replacement, and
  `backend/tools/pydantic_shim.py` provides a strict stand-in for the slice of
  pydantic that `schema.py` uses. Both are labelled at every run and both defer
  to the real library when it is importable, so CI cannot silently diverge.
- **The legal rule engine now genuinely executes here** (this is new; it was a
  collection error before), but its required-field, `ge`/`le` and `extra=forbid`
  guarantees are currently enforced by the shim rather than by pydantic. The shim
  is deliberately strict for that reason — it caught an invalid `ImageQuality`
  field during this session. Even so, **the suite must be re-run under real
  pydantic before any release claim.**
- **`test_auth` is still a collection error** (needs fastapi). The auth, API and
  DB layers have not been executed in this environment at all.
- Barcode/QR decoding (`pyzbar`) is unavailable, so that path is unexercised.

A refactor of `schema.py`'s models to plain dataclasses was considered as a
cleaner fix and **deliberately rejected**: `schema.py` is also imported by
`main.py`, `persistence.py` and `ocr_extraction.py`, none of which can be
executed here either, so the refactor could not have been verified. Rewriting
working legal code that cannot be re-tested is the larger risk.

### What may NOT be claimed at the end of this session
The vision layer (preprocessing, region detection, orientation, OCR routing,
fusion) is tested and measured on real dataset photographs. The rule engine's
legal-safety invariants are tested. Nothing here justifies "verified", "production
ready" or "SIH DEMO READY" for:
- the API, auth or database layers (never executed here),
- OCR *accuracy* (there is still no labelled ground-truth set; `usable_chars` is
  a regression proxy and cannot distinguish a correct read from a confident
  misread),
- end-to-end camera → report workflow (not yet run end to end).

### Exact next actions (priority order)
1. Install real pytest + pydantic + fastapi in an unrestricted environment and
   re-run the whole suite. Until that happens, every count above carries the
   shim caveat.
2. Improve OCR variant RANKING (the one remaining speed lever, above). Success
   criterion: `OCR_VARIANT_SLOTS` 3 → 2 without losing recall on image 3.
3. Build a labelled ground-truth set for a handful of dataset images so accuracy
   can be stated instead of proxied.
4. Rules 4, 5, 25, 26(b)/(c), 27, 31 evaluators (unchanged from Session 1).
5. Frontend: the auth-less dashboard P0 blocker is still open.

---

## Session 4 — 2026-09-08 — P0-1 EVIDENCE INTEGRITY

**Suite after this session: 249 passed / 1 failed / 10 skipped.**
The single failure is the pre-existing `test_auth` collection error
(`ModuleNotFoundError: No module named 'fastapi'`), unchanged from Session 3. The
10 skips are `test_api_integration`, which needs a live server. Nothing was
skipped to make a number look better.

### FEATURE

Evidence traceability (P0-1): a legal finding must be traceable to the exact
source image and the region within it, **and must still be after persistence and
reload**. This is invariant 17 of the 18.

### OBJECTIVE

Close the gap between the evidence contract that `schema.py` described and what
the running system actually produced and stored.

### IMPLEMENTED

Four defects, found by tracing the chain rather than by any failing test. Each one
produced **plausible-looking output**, which is why none had surfaced.

1. **The region was computed and then dropped.**
   `main._field_to_raw_extraction` constructed `RawExtraction` without `bbox` or
   `evidence`. Consequence, traced through the code: `RawExtraction.bbox` was
   `None` for every field in the live pipeline, so
   `rule_engine._evidence_for_extraction` returned `[]` at its
   `if bbox is None` guard, so **every fact the API produced carried
   `evidence == []` and `bbox == None`**, and `ExtractedFact.evidence_image` was
   additionally hardcoded to `None`. OCR had produced correct bboxes in
   original-image coordinates the whole time; they were discarded one call before
   they were needed.

   Fixed by moving the translation into `capture_session.build_raw_extraction()`
   and adding `capture_session.stamp_provenance()`, called at both live OCR sites
   in `main.py`. Provenance is stamped **per field, before the session merge**,
   because `merge_classified_fields` picks a winner per field: `mrp` may win from
   the back panel while `net_quantity` won from the front. A request-level image
   id would attribute some findings to the wrong photograph, which is worse than
   no attribution — it sends a reviewer to an image that does not contain the
   text.

   The translation moved out of `main.py` specifically so it could be tested:
   `main.py` imports FastAPI, which is absent in this environment, so nothing
   living there was reachable by a test at all.

2. **A missing source image was recorded as a plausible filename.**
   `_evidence_for_extraction` used `image_id="unknown"`, which is
   indistinguishable from a real photograph named `unknown.jpg` once it is a
   database row or a printed report line. Replaced with
   `schema.UNATTRIBUTED_IMAGE_ID = "UNATTRIBUTED-NO-SOURCE-IMAGE"`, plus
   `EvidenceReference.is_attributed()` / `.is_locatable()`. `_make_fact` now
   derives its top-level pointers from the evidence list and will only promote an
   **attributed** reference, so the sentinel cannot resurface as a real-looking
   name.

3. **Findings were never persisted at all.** There was no `inspection_findings`
   table. `save_inspection()` wrote products, inspections and facts only, so every
   `RuleFinding` — the object carrying the requirement evaluated, the rule version
   applied, the evidence it rested on and what evidence was *missing* — was
   discarded when the request ended, and `get_inspection_detail()` returned none.

4. **The report claimed traceability it never showed, and silently substituted
   facts for findings.** `report.py` did
   `rows_source = findings if findings else facts` under a "Rule Findings"
   heading, closing with a fixed sentence asserting that "Every finding above is
   traceable to a versioned rule identifier, the underlying extracted evidence,
   and a confidence score" — while rendering only rule id, status, reason and
   confidence. No image, no region, no rule version.

   Because of defect 3 the fallback was the branch **always** taken in the live
   path. Every report this system has ever generated rendered extracted facts
   while presenting them as legal findings. It produced a plausible document
   instead of an error, which is exactly why it went unnoticed.

   Fixed by extracting the pure `report.build_findings_section()`, adding an
   Evidence column that prints `front_7f3a.jpg @ (120,640) 300x28px`, adding a
   Rule version column, disclosing fact-substitution in a conspicuous box,
   folding `missing_evidence` into the reason so "not observed" stays distinct
   from "observed and contradicts", and deriving the closing statement from the
   rows that were actually rendered.

Also: invariant 8 (a client-supplied `VERIFIED` measurement flag is not proof of
verification) is now enforced in `build_raw_extraction` — `VERIFIED` is downgraded
to `ESTIMATED` unless the observation carries a calibration that says of itself it
was validated AND a `pixels_per_mm`. The measurement value is preserved so
geometry/calibration can re-establish `VERIFIED` later.

### FILES CHANGED

- `backend/capture_session.py` — `stamp_provenance`, `build_raw_extraction`,
  `new_surface_id`, `_has_validated_calibration`, `_bbox_from_sequence`;
  `build_surface_observation` takes `surface_id`.
- `backend/schema.py` — `UNATTRIBUTED_IMAGE_ID`, `is_attributed`, `is_locatable`.
- `backend/rule_engine.py` — `_evidence_for_extraction` sentinel;
  `_make_fact` derives `evidence_image`/`bbox` from evidence.
- `backend/main.py` — delegates `_field_to_raw_extraction`; stamps provenance at
  the `/inspect` and session-capture OCR sites.
- `backend/db/schema.sql` — new `inspection_findings` table + 4 indexes.
- `backend/db/persistence.py` — `FINDING_COLUMNS`, `build_finding_row`,
  `decode_json_column`, `hydrate_finding_row`; findings INSERT in
  `save_inspection` and SELECT in `get_inspection_detail`; psycopg2 import made
  non-fatal with a loud `get_conn` guard.
- `backend/report.py` — `build_findings_section`, `_evidence_cell`, `_bbox_text`,
  `_is_locatable`, `_missing_evidence_text`; findings table restructured.
- `backend/tools/probe_evidence_chain.py` — new diagnostic.
- `backend/tests/test_capture_session.py` (9 → 24),
  `backend/tests/test_persistence_evidence.py` (new, 12),
  `backend/tests/test_report_evidence.py` (new, 33).

### SPECIALIST WORK USED

None. `CLAUDE 1/`, `CLAUDE 2/` and `CLAUDE 4/` were inventoried (INSPECT stage
only) and nothing was integrated. That is deliberate: the user's own directive
states that evidence contracts must stabilize before final legal evaluation, and
`CLAUDE 2`'s evidence-fusion work and `CLAUDE 4`'s geometry work both have to
satisfy this contract. Merging them into a chain that was still dropping regions
would have made the result impossible to attribute. The folders are untouched.

### TESTS ADDED

45 new tests. The ones that matter most:

- `test_the_bbox_actually_reaches_the_rule_engine_fact` — the specific regression.
- `test_provenance_travels_with_the_observation_that_wins_the_merge` — two
  panels; asserts `mrp` traces to `back.jpg` and `net_quantity` to `front.jpg`.
- `test_an_unattributed_observation_is_not_given_a_plausible_filename`.
- `test_a_client_supplied_verified_measurement_is_downgraded`, with
  `test_a_validated_calibration_permits_verified` as a non-vacuity guard.
- `test_a_finding_survives_the_round_trip_with_its_source_image_and_region`.
- `test_missing_and_required_evidence_stay_distinguishable_after_reload`.
- `test_the_findings_column_set_and_row_builder_agree` — guards INSERT drift.
- `test_the_source_image_and_region_appear_in_the_rendered_pdf` — reads text back
  out of a generated PDF.
- `test_the_rendered_pdf_does_not_present_facts_as_rule_findings`.
- `test_a_region_without_a_source_image_also_counts_as_unshowable`.

### TESTS RUN

249 passed, 1 failed (pre-existing `test_auth`, needs fastapi), 10 skipped
(`test_api_integration`, needs a live server).

Both new test files were checked for **non-vacuity by reintroducing the defect**:
putting `"evidence_json": None` back into `build_finding_row` fails 4 persistence
tests; restoring the unconditional "Rule Findings" heading and the fixed
traceability sentence fails 4 report tests. A test that cannot fail is not
evidence.

Two verifications that are not unit tests:
- `python backend/tools/probe_evidence_chain.py` — **0 of 10 facts locatable
  before the fix, 5 of 10 after.** The remaining 5 are declarations never observed
  in the fixture, which correctly carry no region.
- The `inspection_findings` DDL was parsed out of `schema.sql` and diffed against
  `FINDING_COLUMNS` programmatically: no column written that the table lacks, no
  column in the table never written. This is the failure mode a pure unit test
  cannot see, because both sides would agree with each other while disagreeing
  with the database.

### END-TO-END VERIFIED

**Partially, and the boundary matters.**

Verified by running: OCR-shaped input → provenance stamp → `RawExtraction` →
`run_inspection` → facts carrying image id + region → `build_finding_row` → JSON →
`hydrate_finding_row` → `build_findings_section` → **a real PDF whose extracted
text contains `front_7f3a.jpg` and `(120,640) 300x28px`**. A reviewer holding that
page can find the pixels.

NOT verified: the HTTP request path and the live SQL. There is no network in this
environment, so `fastapi` and `psycopg2` cannot be installed and no PostgreSQL
server can be started. What is tested is the code that decides *what* is written
and *how* it is read back, which is where evidence gets silently dropped — but the
`INSERT`/`SELECT` themselves have not executed.

### PERSISTENCE VERIFIED

**Serialization boundary: yes. Database: no.** Do not restate this as
"persistence verified" without qualification. The findings INSERT is additionally
guarded by an `information_schema.tables` check so an un-migrated database keeps
working rather than erroring, and the findings SELECT is wrapped so that a read
failure sets `findings_unavailable` and rolls back instead of taking the whole
inspection down — and the report now prints a conspicuous warning when it sees
that flag.

### USER WORKFLOW VERIFIED

No. The inspector's camera → capture → review → report path has not been run end
to end, because the API layer cannot start here.

### KNOWN LIMITATIONS

- Live DB round trip and HTTP path unexecuted (above).
- 5 of 10 facts in the probe fixture remain without evidence. That is correct
  behaviour — those declarations were never observed — but it means a report on a
  real package will legitimately show "no evidence recorded" rows, and the closing
  statement will count them. This is honest, not a defect.
- `pdftotext`-based tests skip where poppler is absent. The skip reason states
  that only the section model is verified in that case.
- The report's *layout* is verified only by text extraction, not visually. Column
  widths were corrected once already: bare-string header cells cannot wrap, so
  "Rule version" overflowed into "Status" and the printed table read
  "Rule versionStatus". Header cells are now `Paragraph`s. Look at a rendered page
  before a demo.
- Everything still carries the shim caveat: the runner is
  `backend/tools/run_tests.py`, not real pytest, and `schema.py` validates through
  `backend/tools/pydantic_shim.py`.

### SECURITY

No change to auth, RBAC or secret handling. No credentials added; nothing
committed. One robustness improvement: `decode_json_column` returns `None` on
malformed JSON rather than raising, so a corrupt `evidence_json` blob costs the
reader that one region instead of making the whole inspection unreadable.

### LEGAL RISKS

The defect fixed in item 4 was itself a legal risk: a document that presented
extracted observations as rule findings, asserting traceability to a versioned
rule that did not exist for those rows. Any report generated before this change
should be treated as unreliable as a record of evaluation. The report now states
only what it can show, and counts the findings it cannot show.

Unchanged: no accuracy claim is possible. There is still no labelled real-photo
ground-truth set. The only labelled set in the workspace is `CLAUDE 1/dataset/`,
which is self-marked `"synthetic": true` and *"Do not use as compliance
evidence."*

### NEXT FEATURE

P0-1 is closed at the contract level. Next, per the specialist directive's stated
dependency order: COMPARE and selectively integrate `CLAUDE 2`'s vision/evidence
work (`evidence_fusion.py`, `vision_pipeline.py`, `orientation_ocr.py`) against
canonical `ocr_extraction.py` / `ocr_engine.py`, now that the evidence contract it
must satisfy is stable and tested. Then `CLAUDE 4` geometry/calibration, which
must satisfy the same contract plus the uncertainty rules. Then `CLAUDE 1`
frontend, including the still-open `dashboard.html` auth blocker.

---

## Session 3 — Master Architecture Unification & Legal Evaluator Expansion

Executed in strict compliance with `SIH 2026 — MASTER IMPLEMENTATION PLAN.md`.

### 1. Architecture Inventory & Contracts (Phase 1)
- Completed exhaustive inventory of all specialist branches (`CLAUDE 1`, `CLAUDE 2`, `CLAUDE 4`, `CLAUDE 5`, `backend`, `frontend`, `rules`).
- Generated root `ARCHITECTURE_INVENTORY.md` detailing subsystem ownership, dependencies, interfaces, and integration paths.
- Fixed `backend/config.py` hard import of `dotenv` so environment isolation and minimal runners without python-dotenv execute without crashing.
- Extended `backend/schema.py` with additive, non-breaking models and enums for geometry, calibration, and physical measurements (`MeasurementMode.NOT_OBSERVED`, `PackageShapeHint`, `CalibrationMethod`, `PDPObservationStatus`, `GeometryReadiness`, `PackageGeometry`, `PDPGeometry`, `RectificationResult`, `PhysicalMeasurement`, `GeometryReadinessResult`).

### 2. Geometry & Calibration Integration (Phase 2)
- Unified pure Python pixel-to-mm scaling, reference card calibration math (ID-1 85.6mm long edge), uncertainty propagation, and Rule 7(1) PDP area formulas into canonical `backend/calibration.py`.
- Integrated classical CV contours, `approxPolyDP`, ellipse fitting, PDP candidates, and homography rectification into canonical `backend/geometry.py`.
- Preserved physical measurement safety: arbitrary photographs without validated calibration yield `MeasurementMode.UNCERTAIN` or `ESTIMATED`, never fabricating `VERIFIED` measurements.

### 3. Legal Engine Expansion & Invariant Hardening (Phase 3)
- Enforced Legal Safety Invariant 4 (`agreement_cap`): conflicting OCR readings cap definitive PASS/FAIL verdicts to `UNCERTAIN` with `review_required = True`.
- Implemented missing rule evaluators in `backend/rule_engine.py`:
  - **Rule 4**: Multi-pack declarations (inner retail packages must retain retail declarations).
  - **Rule 5 & Second Schedule**: Standard package quantities and non-standard declaration verification.
  - **Rule 25**: Export package domestic sale restriction (prohibits unlabelled/unrepacked sale of export packages in India).
  - **Rule 26(b) & 26(c)**: Fast food restaurant-packed and Drug Price Control Order formulation specific exemptions.
  - **Rule 27**: Manufacturer/Packer/Importer registration reference checks.
  - **Rule 31**: E-commerce / advertisement retail price and mandatory net quantity declarations.
- Wired calibrated PDP area and numeral height measurements into `run_inspection()`.
- Added automated AST drift guard ensuring all `_finding()` calls pass `fact=`.
- Added comprehensive unit tests in `backend/tests/test_rule_engine.py`. Test suite expanded from 34 to 40 passing tests with zero regressions.

### 4. Frontend & Auth Hardening (Phase 4)
- Canonicalized React application: copied complete TypeScript/React app from `CLAUDE 1/frontend/react-app` to `frontend/react-app`.
- Hardened `frontend/dashboard.html` with bearer token input, state persistence in `localStorage`, and `Authorization: Bearer <token>` injection across `/scan`, `/inspections`, and review endpoints, resolving the 401 unauthenticated blocker.

### Test Verification Status
- Runner: `backend/tools/run_tests.py` using codex runtime (Python 3.12, pydantic 2.13.4, reportlab, numpy, pillow).
- Results: **132 passed, 0 failed, 10 skipped** (6 test modules requiring system `cv2` or `fastapi` in this sandboxed environment cleanly report collection errors).

---

## Session 4 — OCR Pre-fill, Capture-Confirm Streamlining, and Cross-Surface Consistency

Addressed outstanding integration requirements from `antigravity.md`:

### 1. OCR Pre-fill Preview Endpoint (`POST /extract-preview`)
- Added `POST /extract-preview` in `backend/main.py`: takes single or multi-surface captured images, executes `run_ocr()` + `classify_fields()` across surfaces, stamps provenance, and returns structured field extractions and smart suggestions (`suggested_product_id`, `category`, `net_quantity_value`, `net_quantity_unit`, `mrp`).
- Operates statelessly without database persistence or prior metadata requirements.
- Relaxed `POST /scan` to permit optional `product_id` and `net_quantity_value`, falling back intelligently to OCR extractions, slugified common names, or auto-generated scan IDs.

### 2. Frontend Capture-Confirm Flow Pre-population
- Updated `frontend/react-app/src/lib/api-client.ts`: added `extractPreview()` and `ExtractPreviewResponse` type contracts.
- Overhauled `ScanDetailsView` in `frontend/react-app/src/components/InspectionApp.tsx`:
  - Automatically triggers `extractPreview()` as soon as photos are captured.
  - Displays a clean scanning preview banner while OCR processes.
  - Automatically pre-populates Product ID, Sale Type, Category, Net Quantity, Unit, and MRP with detected values.
  - Added visual provenance badges: "Auto-suggested from label", "Auto-detected", "Detected ₹...".
  - Added collapsible "Detected Declarations" card displaying all recognized package declarations with confidence chips.
  - Enables the "Run compliance check" button immediately when pre-filled, removing manual typing friction.

### 3. Cross-Surface Consistency Verification
- Upgraded `merge_classified_fields` in `backend/capture_session.py` to compare values when multiple surfaces observe the same field:
  - Detects conflicting numeric quantities across surfaces (e.g. front vs back net quantity mismatch).
  - Detects sticker price vs base MRP conflicts.
  - Attaches `alternative_values` and sets `agreement = "CONFLICTING"`, automatically triggering Legal Safety Invariant 4 (`agreement_cap` in `rule_engine.py`) to cap definitive PASS/FAIL to `UNCERTAIN` and flag `review_required = True`.
  - Sets `agreement = "CORROBORATED"` when observations match across surfaces.
- Added 3 new unit tests in `backend/tests/test_capture_session.py` (`test_merge_detects_conflicting_quantities_across_surfaces`, `test_merge_detects_sticker_price_vs_base_mrp_conflict`, `test_merge_corroborates_matching_declarations`).

### Test & Build Verification
- Backend tests: **27/27 passed** in `test_capture_session.py`, **340 passed** across the full unit test suite.
- Frontend build: `npm run build` (`tsc && vite build`) passed with zero errors in 3.72s.

---

## Session 5 — 2026-09-11 — CLAUDE 2 / CLAUDE 4 comparison and split-declaration reconstruction

**Suite after this session: 362 passed, 0 failed, 8 skipped (370 collected).**
Run against a **real** environment for the first time in this project's
history: PostgreSQL 16 (apt), Tesseract OCR (apt), and the full non-PaddleOCR
`backend/requirements.txt` (pip) installed from a clean venv — no shims, no
driverless stand-ins. Prior sessions record no network access to install
`fastapi`/`psycopg2`/PyPI packages at all; this sandbox had it. PaddleOCR was
left uninstalled (large, and `config.py` already fails closed to Tesseract
when it is absent — this is a documented, intentional fallback, not a gap).
The 8 skips are a pre-existing, structural characteristic of
`tests/conftest.py::bootstrap_admin_token`, not something this session
introduced: `main.py`'s `startup()` seeds `admin`/`inspector`/`reviewer`
accounts the moment `TestClient(main.app)` is constructed, which happens
*before* the bootstrap fixture's one-time `/auth/register` call ever runs —
so that call always finds a non-empty `users` table and self-skips by design.
Confirmed this is independent of database state by truncating `users` and
re-running: the skip count did not change, because seeding happens inside the
very fixture the skip-prone tests depend on.

### OBJECTIVE

The person's instruction, verbatim: "CLAUDE 2 AND 4 HAVE DONE WELL, so
integrate them but also check whether their approach is ideal and perfect or
not. Or it would be better to go for another approach." This session is a
comparison, not a blind merge — see CLAUDE MASTERPROMPT.txt section 1 ("DO
NOT blindly merge everything... DO NOT rebuild functioning components merely
because another folder contains a newer-looking version").

### COMPARISON FINDINGS

1. **CLAUDE 4's `geometry.py` / `calibration.py` — already integrated, and
   canonical has since improved on it.** `diff`'d directly against
   `CLAUDE 4/backend/calibration.py`: canonical's version is CLAUDE 4's file
   almost verbatim, with sharper Rule 7(1) failure-reason wording. Canonical's
   `geometry.py` contains every function CLAUDE 4's does (`classify_package_shape`,
   `detect_package_geometry`, `detect_pdp_geometry`, `rectify_pdp`,
   `align_multi_image_surfaces`, ...) *plus* a materially better boundary
   detector added on top: CLAUDE 4's single-strategy `_largest_external_contour`
   was replaced with `_grabcut_foreground_contour` / `_content_region_candidates`
   / `_pick_best_contour` / `strip_letterbox_bars` — GrabCut foreground
   segmentation, letterbox-bar stripping, and multi-candidate selection instead
   of "take the largest contour and hope." **No action needed; do not revert
   to CLAUDE 4's simpler version.**

2. **CLAUDE 2's OCR/orientation pipeline (`orientation_ocr.py`,
   `vision_pipeline.py`, `ocr_engines.py`) — superseded, not missing.**
   CLAUDE 2's approach is a brute-force empirical one: OCR each text block at
   two candidate rotations and keep whichever scores better
   (`_ocr_best_of_two_orientations`). Canonical's `orientation.py` does the
   same *kind* of thing more cheaply and more accurately: ink-mask /
   glyph-elongation / projection-profile geometry produces an ORDERED
   candidate list of rotations per region (`estimate_region_orientation`),
   informed by real domain knowledge documented inline — e.g. vertical text on
   Indian retail packaging usually reads bottom-to-top, so `[90, 270, 0, 180]`
   is tried in that order rather than all four with equal priority — and
   `ocr_engine.py` (`_finish_reading`, ~L1473) then runs actual OCR against
   that ordered list to resolve the residual 0/180 or 90/270 ambiguity geometry
   cannot settle on its own. This *is* CLAUDE 2's "verify by reading" idea,
   just built on a much better prior instead of trying every rotation blind.
   **No action needed.**

3. **CLAUDE 2's `evidence_fusion.py` — mixed; one real gap found and closed.**
   - `classify_multi_engine()` (cross-engine per-field agreement) duplicates
     what canonical's `ocr_engine.fuse_observations()` +
     `schema.EvidenceAgreement` already do, at a more granular level
     (per-observation, across preprocessing variants AND engines, not just
     per already-classified field) and with materially more careful
     documentation of the legal-safety reasoning
     (`EvidenceAgreement.permits_definitive_finding()`,
     `coerce_evidence_agreement()`'s "never default unknown to SINGLE_SOURCE"
     rule). **Not ported — would be a regression to a coarser mechanism.**
   - `reconstruct_split_fields()` — joining a bare declaration label found on
     one photograph (e.g. "MRP Rs" with no digits) to a matching, unlabeled
     value fragment found on a DIFFERENT photograph of the same package — was
     a **genuine, currently-missing capability** (CLAUDE MASTERPROMPT.txt
     section 23, "Multi-Surface Inspection"). It fits the codebase's existing
     safety posture exactly: it never touches a field that already has a full
     value, it refuses to guess when more than one candidate fragment exists,
     and it only ever produces a `review_required=True` result, never a
     confident one. **Ported, adapted, and wired in — see IMPLEMENTED below.**

### IMPLEMENTED

**New module — `backend/evidence_reconstruction.py`.** Adapted from
`archive/CLAUDE 2/proj/backend/evidence_fusion.py::reconstruct_split_fields`,
rewritten against canonical's actual field names/helpers
(`ocr_extraction.FIELD_PATTERNS`, `_extract_money`, `_extract_qty`,
`_normalized_text` — these turned out to have identical names in both
branches, so the port was mechanical) and canonical's `schema.EvidenceAgreement`
instead of CLAUDE 2's separate `EvidenceVerification` enum. A successful
reconstruction is stamped `agreement=AGREEMENT_UNKNOWN` (a synthesised join is
not the same claim as two independent full readings that were compared and
found to agree — `CORROBORATED` would overclaim it) and
`review_required=True`, so `EvidenceAgreement.permits_definitive_finding()`
already guarantees it can never by itself produce a definitive PASS.

**Schema change — `backend/db/schema.sql`.** Added
`session_captures.ocr_raw_lines_json JSONB` (plus the matching
`ALTER TABLE ... ADD COLUMN IF NOT EXISTS` for already-initialized databases,
following the file's existing convention for `inspections.declarations_json`).
This was necessary, not optional: `classify_fields()` only retains OCR lines
that matched a recognised label, so a bare, unlabeled fragment on one capture
was previously discarded before it ever reached persistence, and cross-image
reconstruction at finalize time would have had nothing to search. The new
column is a lean `[{text, bbox, confidence}, ...]` projection, not the full
`OcrLine` (no `fusion_state`/`alternatives`/`region_id` — those already live
on `ocr_fields_json` for whichever reading won classification; duplicating
them here would let two copies of the same evidence drift apart).

**Persistence — `backend/db/persistence.py`.** `add_session_capture()` gained
an optional `ocr_raw_lines` parameter (defaulted to `None`, so every existing
caller is unaffected); `list_session_captures()` decodes it defensively the
same way it already decodes `ocr_fields_json` and `surface_observation_json`
(handles both a native-decoded JSONB object and a raw JSON string).

**Wiring — `backend/main.py`.**
- `add_capture()` now serialises each capture's `ocr_lines` via the new
  `_serialize_ocr_lines_for_reconstruction()` helper and persists them.
- New helper `_apply_split_field_reconstruction(accumulated_fields, captures)`
  rehydrates every OTHER capture's raw lines into `OcrLine` objects, calls
  `evidence_reconstruction.reconstruct_split_fields()`, and folds any result
  into the field map — but only for a field that is STILL label-only at the
  moment of merge (defence in depth beyond the module's own guarantee, in
  case a later capture in the same batch already completed the field through
  the ordinary `merge_classified_fields()` path).
- Called from **both** `get_session_status()` (so a reconstructed field can
  surface to the inspector — and stop capture guidance from asking for a
  declaration that has, in fact, already been found across two photos — as
  soon as it becomes unambiguous, not only at the end) and
  `finalize_session()` (so it actually reaches the rule engine). It is
  deliberately NOT called per-capture inside `add_capture()` itself: a single
  new capture cannot see fragments from captures made AFTER it, so the
  reconstruction attempt has to run against the full set of surfaces
  collected so far, not one at a time.

### TESTED

- `backend/tests/test_evidence_reconstruction.py` — 8 new pure unit tests
  (label+fragment join across two images; net_quantity and batch_no variants,
  not just mrp; a numeric label already has a value and must be left alone;
  two ambiguous candidate fragments must be refused, not guessed between; no
  candidate leaves the field untouched; a same-image fragment does not
  complete its own label; a second occurrence of the label text itself is not
  mistaken for a bare fragment). All 8 passed on first run.
- `backend/tests/test_api_integration.py::test_split_declaration_reconstructed_across_two_real_captures`
  — end-to-end through the real FastAPI app and the real Postgres JSONB round
  trip for the new column: two captures written via `db.add_session_capture()`
  directly (deterministic — this test does not depend on Tesseract reading a
  synthetic image the way a person would; the OCR/vision layer itself is
  already exercised elsewhere against real dataset photographs), then
  `GET /sessions/{id}` and `POST /sessions/{id}/finalize` both checked to
  confirm the reconstructed `mrp` value actually reaches the response and the
  rule engine, not just the in-memory module. Passed.
- Full existing suite re-run after every change: unaffected throughout
  (353 → 362 passed as the 9 new tests were added; 0 newly broken).

### NOT DONE / OUT OF SCOPE THIS SESSION

- CLAUDE 2's `product_identity.py` (70 lines), `package_boundary.py` (88
  lines), `live_capture.py` (173 lines) and `measurement.py` (71 lines) were
  NOT individually diffed against canonical's much larger `barcode_decode.py`
  (787 lines), `geometry.py`'s boundary detection, and the `MeasurementMode`
  states already in `calibration.py`/`schema.py`. Given the pattern found in
  every module that WAS compared this session, these are very likely already
  superseded rather than missing — but that is an inference from pattern, not
  a verified finding, and should not be presented as one. **Flag as NOT
  VERIFIED**, not as "also fine."
- CLAUDE 1 (frontend) and CLAUDE 5 were not examined this session.
- The RAG subsystem (CLAUDE MASTERPROMPT.txt sections 14–20) remains
  unaddressed; this session's scope was strictly the vision/evidence
  comparison the person asked for.

---

## Session 6 — 2026-09-12 — Multi-versioned rule engine (section 11) and CORE RAG (sections 14-20)

**Suite after this session: 419 passed, 0 failed, 8 skipped (427 collected).**
The 8 skips are the same pre-existing, structural `bootstrap_admin_token`
condition documented in Session 5 — unrelated to this session's work.
64 new tests added (12 rule-versioning/historical-reproducibility, 45 RAG,
plus a handful folded into `test_api_integration.py`), all passing on a real
run against real Postgres, not a shim.

Note on this sandbox: PostgreSQL does **not** reliably stay running between
separate tool invocations in this container — it had to be restarted several
times over the course of this session. This is an environment quirk, not a
code issue; every result below was re-confirmed after a fresh restart
immediately before running it.

### OBJECTIVE

Direct instruction from the person: "Focus on RAG and multiversioned Rule
Engine. Get those perfect." "Perfect" is not a claim this entry makes for
either piece — see NOT DONE / KNOWN LIMITATIONS below for both. What follows
is what was actually built and actually verified.

### PART 1 — MULTI-VERSIONED RULE ENGINE (section 11)

**What was there before this session:** `rules/rules.json` already had
`effective_from`/`effective_to`/`version` fields per rule — but exactly ONE
JSON object per `rule_id`, and `rule_engine.load_rules()` raised
`ValueError: Duplicate rule_id` if a second one ever appeared. This was
version *labelling*, not version *resolution*: the `effective_from` on
`LMPC-2011-R7-2-FONT` correctly documented that the PDP-area font-height
bands took effect 2018-01-01, but there was no PRIOR row for the flat
pre-2018 rule, and no code path that could have picked the right one for a
given date even if there were. An inspection dated in 2015 would silently
have been evaluated against 2018 thresholds.

**New module — `backend/rule_versioning.py`.** Groups `rules.json` entries by
`rule_id` into a real version history and resolves whichever version was in
force on a given `as_of` date. Two safety invariants enforced at LOAD time,
not evaluation time (CLAUDE MASTERPROMPT.txt section 57, "No Silent
Fallbacks"):
  - Two versions of the same `rule_id` must never have overlapping effective
    windows — raises `RuleVersioningError` immediately if they do, rather
    than let resolution silently pick "whichever came first in the file."
  - A date with no version covering it (before the earliest version, or in a
    genuine gap between two versions) resolves to that `rule_id` being
    **absent** from the snapshot, not the nearest version — `_find_rule()`
    already treats "no matching rule_id" as "this rule does not apply",
    which is the correct behaviour for a rule that was not yet (or no
    longer) in force.

**Two real historical rule versions added to `rules/rules.json`**, both
web-search-verified before being written, not invented:
  - `LMPC-2011-R7-2-FONT@2011-04-01` — the pre-amendment flat 1mm/2mm letter
    height rule, replaced by the existing PDP-area-banded rule on
    2018-01-01. Cross-checked against indiankanoon.org's consolidated Rule 7
    amendment history, corroborated by two independent secondary sources
    (Lexology, Legitquest) on the exact 2018-01-01 commencement date. High
    confidence.
  - `LMPC-2011-R6-11-UNIT-PRICE@2011-04-01` — no unit-sale-price declaration
    requirement existed at all before the existing 2023-02-01 row. Marked
    `needs_official_verification`: secondary sources genuinely disagree on
    the exact commencement date across successive deferral notifications
    (dates from October 2022 through mid-2023 appear across different
    sources) — this entry keeps the SAME 2023-02-01 boundary already used by
    the existing post-amendment row rather than asserting a "corrected" date
    nobody here could verify with confidence. Evaluator gets a new
    `requirement_active: false` flag rather than trying to force the
    existing complex unit-price evaluator to handle "this requirement did
    not exist yet" through its normal threshold-comparison path.

**`rule_engine.py` changes** (all additive/backward-compatible — every
existing call site of `load_rules()` or `run_inspection()` that doesn't pass
`as_of_date` behaves exactly as before, defaulting to `date.today()`):
  - `load_rules(path, as_of=None)` now resolves through
    `rule_versioning` instead of loading a flat single-version dict.
  - `run_inspection(..., as_of_date=None)` — the date that selects which
    rule versions apply. This is what makes historical reproducibility work:
    re-evaluating the same evidence against the same `as_of_date` always
    resolves to the same rule versions, regardless of what `rules.json`
    contains by the time it's called — AS LONG AS historical version rows
    are never edited in place, only superseded by new rows. Enforcing that
    discipline is a process rule, not something code can fully guarantee;
    the overlap-detection check above is the automated backstop.
  - `_min_numeral_height_mm()` / `_evaluate_font_height()` extended to
    support the old flat-threshold shape (no PDP-area dependency at all)
    alongside the existing banded-threshold shape — a missing PDP area must
    not block evaluation under the historical version, since that version
    never needed one.
  - `_evaluate_unit_sale_price()` gained the `requirement_active` gate,
    returning `FactStatus.EXEMPT` (the same status already used for
    wholesale-package non-applicability) with a clear reason when the
    resolved rule version says the requirement did not exist yet.
  - `ExtractedFact`/`RuleFinding` (`schema.py`) gained
    `rule_effective_from`/`rule_version_id` fields (both `Optional[str] =
    None`, additive) so a finding's exact resolved version is auditable
    later — `rule_version_id` is the stable `rule_id@effective_from` key,
    independent of the free-text `version` label.

**TESTED:**
  - `tests/test_rule_versioning.py` (9 tests): grouping/sorting, correct
    window selection at exact boundaries, date-before-earliest-version and
    gap-between-versions both correctly resolve to "not in force" rather
    than guessing, overlapping versions raise at load time, and a smoke test
    that the REAL production `rules.json` has no overlap errors.
  - `tests/test_rule_engine.py` (3 new tests) — the actual safety property
    CLAUDE MASTERPROMPT.txt section 43 #5/#6 demands: same evidence, same
    PDP area, only `as_of_date` changes.
    `test_font_height_uses_historical_flat_rule_before_2018`: 1.2mm at a PDP
    area whose 2018+ band requires 2.0mm — **FAILS** under
    `as_of_date=2026-09-11` and **PASSES** under `as_of_date=2015-06-01`,
    with each finding's `rule_version_id` confirming which row was actually
    used. `test_unit_sale_price_not_required_before_2023_but_is_after`: same
    package, no unit-price evidence either time — EXEMPT before, not EXEMPT
    after. `test_historical_inspection_stable_regardless_of_todays_date`:
    calling `run_inspection()` twice with the same historical `as_of_date`
    produces the identical `rule_version_id`, proving the stability the
    whole mechanism depends on.
  - Full suite re-run after every change: unaffected throughout.

### PART 2 — CORE RAG (sections 14-20)

**Architecture decision, and why:** No separate vector-database service.
`backend/rag/retrieval.py::HybridRetriever` builds an in-process BM25 +
TF-IDF hybrid index (Reciprocal Rank Fusion) from `regulatory_chunks` rows in
Postgres, with a metadata pre-filter on `module` and the
`effective_from`/`effective_to` window. Section 17 permits "the smallest
coherent architecture," and for a few dozen chunks, a Qdrant/FAISS server is
infrastructure section 32 says not to add without real value. Full reasoning
and everything below is written up in **`backend/rag/README.md`** — read
that alongside this entry; it is not duplicated in full here.

**The one non-negotiable:** `rag/service.py::answer_query()` checks
`is_compliance_decision_request()` BEFORE retrieval runs at all. A
compliance question never reaches the retriever — no extractive answer is
even attempted for it. This was tested end-to-end during development, not
just unit-tested afterward, and it caught two real gaps: an earlier regex
missed "Is this product legally compliant?" and "Does my product comply with
regulations?" outright. Both are now explicit regression tests in
`tests/test_rag_query_routing.py`.

**Gemini embeddings are implemented but NOT VERIFIED in this sandbox** —
measured, not assumed: `socket.create_connection` to
`generativelanguage.googleapis.com:443` succeeds, but the TLS handshake then
fails with `CERTIFICATE_VERIFY_FAILED` (self-signed cert from this
environment's egress proxy). `GeminiEmbeddingProvider.is_available()` does a
real connectivity probe, bounded by a hard background-thread timeout (a
per-call `request_options` timeout alone was measured to NOT reliably stop
this SDK's gRPC retry behaviour against a blocked connection), and falls
back to `TfidfEmbeddingProvider` — mirroring `config.py`'s existing
PaddleOCR→Tesseract fail-closed pattern. TF-IDF is the tested, working
default; Gemini is the seam a deployment with real network access should get
almost for free.

**Real bugs found by actually running this end-to-end, not just unit
testing each piece in isolation** (documented in detail in
`backend/rag/README.md`, summarized here):
  1. The Gemini connectivity check originally hung indefinitely rather than
     failing fast — the FIRST end-to-end test run hit a 300-second tool
     timeout because of it. Fixed with the hard-timeout wrapper above.
  2. "Is this product legally compliant?" — textbook compliance question —
     was NOT caught by the first version of the guard regex and got a
     confidently GROUNDED answer about an unrelated topic. This is the most
     serious bug found this session. Fixed and now has 9 regression test
     cases.
  3. An off-topic query ("What is the airspeed velocity of an unladen
     swallow?") returned `GROUNDED` with 0.98 confidence and a real rule_id,
     because (a) Reciprocal Rank Fusion always produces a "rank 1" candidate
     regardless of absolute relevance, and (b) BM25 had no stopword
     filtering, so "is/the/of/an" alone cleared the relevance floor for any
     query. Fixed with an absolute BM25+cosine floor checked before fusion,
     plus stopword stripping in the BM25 tokenizer. Now returns
     `NOT_FOUND_IN_KNOWLEDGE_BASE` correctly.
  4. "What is the minimum **font** height..." ranked a general PDP-definition
     chunk above the actual font-height rule chunks, because the corpus
     (correctly) uses "**letter**/**numeral** height," not "font height" — a
     genuine TF-IDF vocabulary-mismatch limitation, not a bug to "fix" by
     rewording the legal corpus to match colloquial phrasing. Documented as
     a known limitation; queries using the corpus's own terminology retrieve
     correctly and are what the passing tests use.

**The corpus** — `backend/rag/corpus/lmpc_corpus.json`, 16 chunks covering
the same LMPC rules `rule_engine.py` evaluates, hand-authored from
cross-referencing indiankanoon.org / Lexology / Legitquest / iPleaders
commentary against the existing rule engine, honestly tagged
`source_tier: "SECONDARY"` throughout (not a direct Gazette ingestion).
Chunks documenting a rule the engine also evaluates carry that exact
`rule_id`/`rule_version_id`, so a RAG citation and a deterministic finding
can be cross-checked — verified directly in
`test_rag_service.py::test_rule_id_cross_links_to_rule_engine_dataset`,
which resolves the SAME rule through both `rule_versioning.py` and the RAG
retriever and asserts they agree.

**IMPLEMENTED:** `backend/rag/` package (`models.py` — the section 19
response contract field-for-field; `embeddings.py`; `retrieval.py`;
`query_routing.py`; `ingestion.py`; `service.py`; `corpus/lmpc_corpus.json`;
`README.md`); `backend/tools/seed_rag_corpus.py` (standalone, not
auto-run-on-startup, matching `rebuild_product_index.py`'s convention);
`db/schema.sql` — `regulatory_documents`/`regulatory_chunks` tables;
`db/persistence.py` — `upsert_regulatory_document`/`upsert_regulatory_chunk`/
`list_regulatory_chunks`; `main.py` — `POST /rag/query` (inspector-auth
protected, per-module in-process retriever cache).

**TESTED:**
  - `test_rag_query_routing.py` (21 tests) — 9 compliance-guard positive
    cases, 6 negative cases (legitimate explanatory questions must NOT be
    flagged), the rest covering the other 8 QueryType classifications.
  - `test_rag_retrieval.py` (9 tests, synthetic corpus, no DB) — lexical
    relevance, effective-date filtering at exact boundaries, gap-excludes-
    entirely, module/rule_id filtering, nonsense-query and stopword-only-
    query both correctly return no hits, scores bounded [0,1].
  - `test_rag_ingestion.py` (5 tests) — the real corpus loads and validates
    cleanly, plus rejection of missing fields / unknown doc_id / invalid
    source_tier / duplicate chunk_id.
  - `test_rag_service.py` (8 tests, real Postgres + real ingested corpus,
    not a fixture) — full response contract present, compliance question
    never reaches retrieval, historical vs. current font rule resolved
    correctly by date, unit-sale-price history resolved correctly by date,
    citations carry rule references and effective dates, off-topic query is
    NOT_FOUND not hallucinated, and the rule_id cross-link to
    `rule_versioning.py` actually matches.
  - `test_api_integration.py` (+2 tests) — the real HTTP route end-to-end
    (auth, date parsing including a malformed-date 400 case, response
    serialization), and that the endpoint requires auth.
  - Full suite re-run after every change: unaffected throughout.

### NOT DONE / KNOWN LIMITATIONS (both parts)

- **Rule versioning** covers 2 of the ~11 rules currently in `rules.json`
  with real multi-version history (font-height, unit-sale-price) — chosen
  because they are the two rules with a real, findable historical amendment.
  The other rules have exactly one version each (their whole history since
  2011), which is not a gap to fix, just what's true — but the MECHANISM now
  exists for the next real amendment to any rule to be added the same way.
- The unit-sale-price amendment's exact commencement date is flagged
  `needs_official_verification` — genuinely uncertain from secondary sources
  alone; confirm against the Gazette before relying on that specific
  boundary for a real decision.
- **RAG** has no reranking step (section 17 lists this as optional) and no
  LLM-based query classification (this sandbox cannot reach any LLM API to
  build or test one against — the heuristic classifier is an honest MVP with
  a documented seam to replace it).
- The full section 16 ingestion pipeline (PDF/DOCX/scanned → OCR → legal
  structure extraction) is NOT built — this is curated-JSON ingestion only.
  Amendment ingestion/diff/approval (sections 11-13, 36) remains entirely
  unaddressed; it was not part of what was asked this session.
- FSSAI/CDSCO/other modules: the schema and code are module-agnostic (a
  `module` column drives everything), but no second module's corpus exists
  to prove that in practice.
- TF-IDF's vocabulary-mismatch limitation (see above) is real and will
  affect any query that uses colloquial phrasing not matching the corpus's
  legal terminology, until/unless a real embedding provider (the Gemini seam)
  is actually reachable in whatever environment runs this next.


