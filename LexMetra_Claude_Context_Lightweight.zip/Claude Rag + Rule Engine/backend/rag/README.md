# RAG subsystem (backend/rag/)

Implements CLAUDE MASTERPROMPT.txt sections 14–20. Read this before touching
anything here — several design choices below exist because a more obvious
alternative was tried first and found to have a real problem in this
environment.

## The one rule that matters most

**RAG never decides PASS/FAIL.** `rag/service.py::answer_query()` checks
`query_routing.is_compliance_decision_request()` *before* retrieval even
runs. A question like "Is this product legally compliant?" never reaches the
retriever, let alone gets an extractive answer built for it — it gets a
fixed redirect to the deterministic rule engine
(`GroundingStatus.DECISION_OUT_OF_SCOPE`). This is deliberately not just one
branch of the nine-way `QueryType` classifier: a misclassification there must
not be able to bypass it. See `tests/test_rag_query_routing.py` — two of its
guard patterns exist specifically because an earlier, narrower regex missed
"Is this product legally compliant?" and "Does my product comply with
regulations?" when this was tested end-to-end. Don't loosen these patterns
without re-running that test file.

## Architecture: why no vector database

Section 17 permits "the smallest coherent architecture that satisfies the
requirements" and section 32 makes PostgreSQL the authoritative store for
regulatory metadata. There is no Qdrant/FAISS/etc. service here — retrieval
(`retrieval.py::HybridRetriever`) builds an in-process BM25 + TF-IDF hybrid
index from `regulatory_chunks` rows at construction time. For a corpus this
size (a few dozen chunks), a separate vector-DB service is infrastructure
the master prompt's own section 32 says not to add "unless it provides
actual value" — it wouldn't here.

Retrieval is genuinely hybrid: BM25 (sparse/keyword, via `rank_bm25`) and
TF-IDF cosine similarity (the "dense" substitute, via scikit-learn) are
combined with Reciprocal Rank Fusion, after a metadata **pre-filter** on
`module` and the `effective_from`/`effective_to` window for a given
`as_of` date.

## Why TF-IDF and not real embeddings — measured, not assumed

Section 21 says to use the existing `GEMINI_API_KEY`. It's genuinely set in
`backend/.env`. `embeddings.py::GeminiEmbeddingProvider` is implemented
correctly against the same `google.generativeai.embed_content` shape already
used elsewhere in this codebase (`vlm_verifier.py`). It is **not verified in
this sandbox**: a direct test here shows `socket.create_connection` to
`generativelanguage.googleapis.com:443` succeeds, but the TLS handshake then
fails with `CERTIFICATE_VERIFY_FAILED` (self-signed cert) — the egress proxy
here intercepts and blocks that domain. `GeminiEmbeddingProvider.is_available()`
does a real (hard-timeout-bounded) connectivity probe and fails closed to
`TfidfEmbeddingProvider` — see `retrieval.py::build_default_retriever()`,
mirroring `config.py`'s existing PaddleOCR-unavailable-falls-back-to-Tesseract
pattern. **A deployment with real network access to Google's API should get a
real semantic embedding path essentially for free** by that fallback simply
never triggering; nothing else needs to change.

The hard-timeout wrapper (`embeddings.py::_call_with_hard_timeout`) exists
because `request_options={"timeout": N}` alone does **not** reliably bound a
blocked call in this SDK — measured directly, a blocked connection kept
retrying at the gRPC layer well past the per-call timeout passed to
`embed_content()`. Only a background-thread wall-clock timeout actually
stopped it. Don't remove this wrapper without re-testing that scenario.

### The real limitation this leaves: vocabulary mismatch

TF-IDF/BM25 are lexical, not semantic. Measured directly: querying "What is
the minimum **font height** for declarations?" ranked the general PDP
definition chunk above the actual font-height rule chunks, because the
corpus (correctly, following the actual rule text) says "**letter**
height"/"**numeral** height", not "font height" — a synonym gap pure lexical
retrieval cannot bridge. Query using the corpus's own terminology
("letter height", "numeral height", "unit sale price") and retrieval is
accurate and correctly date-differentiated — see
`tests/test_rag_service.py`'s passing tests, all of which use that
terminology deliberately. A real embedding model (the Gemini seam above)
would close this gap; TF-IDF cannot.

There is also a floor-check for "found nothing at all"
(`RetrievalConfig.min_bm25_score` / `min_cosine_score`) — **required**, not
optional: Reciprocal Rank Fusion is a ranking signal, not a relevance one,
and will always produce a "rank 1" candidate among whatever survives the
metadata filter even when every raw score is ~0. An off-topic query scored a
misleading 0.98 "confidence" before this floor existed. A second real bug
this surfaced: BM25 has no built-in stopword awareness, so "is/the/of/an"
alone cleared the floor for literally any query until `retrieval.py`'s
`_tokenize()` was made to strip the same stopword list `TfidfVectorizer`
already used. Both are covered by regression tests in
`tests/test_rag_retrieval.py`.

## The answer is extractive, not generated

`service.py::_extractive_answer()` returns the actual text of the top
retrieved chunk(s), verbatim — never an LLM paraphrase. No LLM call in this
pipeline is tested in this sandbox (see above), so an "answer" field that
silently depended on an unreachable API, or worse, fell back to this model's
own general knowledge instead of the retrieved corpus, would violate section
19's "do not silently answer from model memory" outright. `grounding_status`
is `NOT_FOUND_IN_KNOWLEDGE_BASE` (not a guess) when nothing clears the
relevance floor.

## The corpus

`corpus/lmpc_corpus.json` — 16 hand-authored, hierarchy-tagged chunks
covering the same LMPC rules `rule_engine.py` evaluates. Every document has
`source_tier: "SECONDARY"`, honestly: this is a locally-curated corpus built
from cross-referencing indiankanoon.org's consolidated Rule 7 amendment
history plus other secondary legal commentary (Lexology, Legitquest, iPleaders)
against what `rule_engine.py` already implements — **not** a direct ingestion
of an official Gazette PDF (see section 35's tier definitions). Two chunks
(`LMPC-CHUNK-R7-FONT-OLD`/`NEW`) are marked
`verification_status: verified_against_indiankanoon_consolidated_rule7_amendment_history`
— cross-checked against two independent secondary sources, high confidence.
Most others are marked `needs_official_verification` — plausible and
carefully paraphrased, but not independently corroborated the same way, and
should be checked against the actual Gazette text before being relied on for
a real enforcement or legal-advice decision. This is not a formality: one
chunk (`LMPC-CHUNK-R6-11-UNIT-PRICE-OLD`/`NEW`) carries an explicit
`legal_note` that secondary sources genuinely disagree on the exact
unit-sale-price amendment's commencement date across successive deferral
notifications — the 2023-02-01 boundary used here matches `rules/rules.json`'s
existing value rather than asserting a "corrected" date nobody here could
verify with confidence.

Chunks that document a rule `rule_engine.py` also evaluates carry that rule's
exact `rule_id`/`rule_version_id` (see `rule_versioning.py`), so a RAG
citation and a deterministic finding can be cross-checked against each other
— see `tests/test_rag_service.py::test_rule_id_cross_links_to_rule_engine_dataset`.
This is a cross-link for auditability, not a dependency in either direction:
RAG still never makes the compliance call itself.

## Re-ingesting / updating the corpus

Edit `corpus/*.json`, then run:

```
python tools/seed_rag_corpus.py
```

This is deliberately **not** run automatically on app startup, the same way
`tools/rebuild_product_index.py` is a standalone step, not a startup side
effect (section 12's "no silent auto-activation" spirit, applied here too:
re-indexing regulatory content is a deliberate action). If a server process
is already running, its in-process retriever cache
(`main.py::_rag_retriever_cache`) won't see the update until the process
restarts or `main.invalidate_rag_retriever_cache()` is called — a documented
limitation for this MVP, not an oversight.

## What is NOT built here

- The full section 16 "PDF/DOCX/scanned document → OCR → structure
  extraction" ingestion pipeline. This is curated-JSON ingestion only.
- Amendment ingestion/diff/approval workflow (sections 11–13, 36) — a
  separate, larger piece of work, out of scope for this session.
- FSSAI/CDSCO/other regulatory modules — the schema (`module` column) and
  `QueryType`/response-contract code are module-agnostic and would accept a
  second module's chunks without changes, but no such corpus exists yet.
- Reranking (section 17 lists this as optional) and a genuine knowledge
  graph (section 37, explicitly optional in the master prompt).
