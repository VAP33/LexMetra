"""
RAG subsystem (CLAUDE MASTERPROMPT.txt sections 14-20).

RAG answers "what rule applies and what does it require" - it never decides
PASS/FAIL. See service.py's module docstring for the boundary enforcement,
and README.md in this directory for the architecture and what is/isn't
verified in this sandbox.
"""
