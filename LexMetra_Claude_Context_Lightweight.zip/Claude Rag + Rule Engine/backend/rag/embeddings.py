"""
Pluggable "dense" embedding provider for the RAG hybrid retriever.

WHY THIS IS TF-IDF, NOT A REAL EMBEDDING MODEL, BY DEFAULT. CLAUDE
MASTERPROMPT.txt section 21 says to use the existing GEMINI_API_KEY for RAG.
This sandbox has a real, populated GEMINI_API_KEY in backend/.env, and
google-generativeai is already a dependency (see vlm_verifier.py). But a
direct test in this environment - `socket.create_connection` to
generativelanguage.googleapis.com succeeds at the TCP level, then the TLS
handshake fails with CERTIFICATE_VERIFY_FAILED ("self signed certificate in
certificate chain") - confirms the egress proxy here intercepts and blocks
that domain; it is not on the allowlist this sandbox's bash tool documents.
Anything that depends on a live Gemini call is therefore UNTESTED in this
environment, not just "not yet tried."

Rather than ship a "RAG" that silently can't retrieve anything meaningful
whenever that call fails, or one whose only tested path requires an API this
sandbox cannot reach, retrieval defaults to a TF-IDF vector space
(scikit-learn) as the "dense-like" half of the hybrid index - see
retrieval.py. TF-IDF is not semantic the way a real embedding model is, but
it is real, local, fully tested end-to-end, and correctly captures similarity
for the kind of short, keyword-anchored regulatory questions this system
handles ("font size requirement", "unit sale price"). GeminiEmbeddingProvider
below is implemented correctly against the documented API shape and is the
seam a deployment WITH real network access should switch to - see
HybridRetriever(embedding_provider=...) in retrieval.py.
"""

from __future__ import annotations

import os

# Must be set before google.generativeai/grpc is imported anywhere. Without
# this, an abandoned connectivity-probe thread (see _call_with_hard_timeout)
# keeps logging "Handshake failed... CERTIFICATE_VERIFY_FAILED" to stderr for
# some time after the probe's caller has already moved on with a fallback -
# harmless to correctness, just noisy.
os.environ.setdefault("GRPC_VERBOSITY", "NONE")

from abc import ABC, abstractmethod
from typing import List, Sequence


class EmbeddingProvider(ABC):
    @abstractmethod
    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        """Return one dense vector per input text, same order."""

    @abstractmethod
    def is_available(self) -> bool:
        """Whether this provider can plausibly serve requests right now."""


class TfidfEmbeddingProvider(EmbeddingProvider):
    """
    Always available. Fits a TF-IDF vector space over whatever corpus it is
    given (see retrieval.HybridRetriever, which fits this once per index
    build) and projects query/document text into it. This is the default,
    tested retrieval path.
    """

    def __init__(self):
        from sklearn.feature_extraction.text import TfidfVectorizer

        self._vectorizer = TfidfVectorizer(
            lowercase=True, ngram_range=(1, 2), min_df=1, stop_words="english",
        )
        self._fitted = False

    def fit(self, corpus_texts: Sequence[str]) -> None:
        self._vectorizer.fit(corpus_texts)
        self._fitted = True

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        if not self._fitted:
            raise RuntimeError("TfidfEmbeddingProvider.fit() must be called before embed()")
        matrix = self._vectorizer.transform(texts)
        return matrix.toarray().tolist()

    def is_available(self) -> bool:
        return True


class GeminiEmbeddingProvider(EmbeddingProvider):
    """
    NOT VERIFIED IN THIS SANDBOX - see module docstring. Implemented against
    the documented `google.generativeai.embed_content` shape used elsewhere
    in this codebase (vlm_verifier.py's `_gemini_provider_call`), so it
    should work in a deployment with real network access to
    generativelanguage.googleapis.com, but no test in this repository
    exercises it end-to-end, and CI here cannot either. `is_available()`
    performs a real (cheap) connectivity check rather than just checking the
    env var is set, so a caller can fail closed to TfidfEmbeddingProvider
    instead of raising mid-query - see retrieval.build_default_retriever().
    """

    def __init__(self, model: str = "models/text-embedding-004"):
        self._model = model

    def is_available(self) -> bool:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            return False
        # `request_options={"timeout": N}` alone does NOT reliably bound this
        # call in this SDK: measured directly in this sandbox, a blocked
        # connection keeps retrying at the gRPC layer well past any
        # per-call timeout passed to embed_content(). A hard wall-clock
        # timeout via a background thread is the only thing that actually
        # bounds it, so that a blocked network fails this check fast instead
        # of stalling every caller of build_default_retriever().
        return _call_with_hard_timeout(self._probe, timeout_seconds=6, default=False)

    def _probe(self) -> bool:
        import google.generativeai as genai

        genai.configure(api_key=os.environ["GEMINI_API_KEY"])
        genai.embed_content(
            model=self._model, content="connectivity check",
            request_options={"timeout": 5},
        )
        return True

    def embed(self, texts: Sequence[str]) -> List[List[float]]:
        import google.generativeai as genai

        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is not set.")
        genai.configure(api_key=api_key)
        vectors: List[List[float]] = []
        for text in texts:
            result = genai.embed_content(
                model=self._model, content=text, request_options={"timeout": 10},
            )
            vectors.append(list(result["embedding"]))
        return vectors


def _call_with_hard_timeout(fn, *, timeout_seconds: float, default):
    """
    Runs `fn` in a background thread and returns `default` if it does not
    complete within `timeout_seconds`, instead of blocking the caller
    indefinitely. The thread itself is a daemon thread - if `fn` really is
    stuck forever (as observed against this sandbox's blocked network), it
    is abandoned rather than joined, which is safe for a short-lived
    connectivity probe but is exactly why this function must never be used
    for anything whose result must be waited for.
    """
    import concurrent.futures

    pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    future = pool.submit(fn)
    try:
        return future.result(timeout=timeout_seconds)
    except Exception:
        return default
    finally:
        # wait=False is essential here: the default wait=True would block
        # shutdown() on the very same hung call this function exists to not
        # wait for, defeating the whole point.
        pool.shutdown(wait=False)
