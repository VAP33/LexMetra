"""
RAG corpus ingestion (CLAUDE MASTERPROMPT.txt section 16).

Loads backend/rag/corpus/*.json, validates every chunk carries the legal
hierarchy/effective-date metadata section 15 requires, and upserts into
Postgres via db.persistence. Deliberately NOT run automatically at app
startup (see backend/tools/seed_rag_corpus.py) - re-ingestion is a
deliberate, explicit action, mirroring how backend/tools/rebuild_product_index.py
is a standalone script rather than a startup side effect.

This is a curated-JSON ingestion path, not the full "PDF/DOCX/scanned/OCR"
pipeline section 16 describes for live document ingestion - see
backend/rag/README.md for what is and is not built.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

CORPUS_DIR = Path(__file__).resolve().parent / "corpus"

REQUIRED_CHUNK_FIELDS = (
    "chunk_id", "doc_id", "module", "effective_from", "text", "source_citation",
)
REQUIRED_DOC_FIELDS = ("doc_id", "title", "source_tier", "jurisdiction")

VALID_SOURCE_TIERS = {"AUTHORITATIVE", "SECONDARY", "EXPLANATORY", "UNVERIFIED"}


class CorpusValidationError(ValueError):
    pass


def load_corpus_file(path: Path) -> Dict[str, list]:
    data = json.loads(path.read_text(encoding="utf-8"))
    documents = data.get("documents", [])
    chunks = data.get("chunks", [])

    doc_ids = set()
    for doc in documents:
        missing = [f for f in REQUIRED_DOC_FIELDS if not doc.get(f)]
        if missing:
            raise CorpusValidationError(f"{path.name}: document missing {missing}: {doc}")
        if doc["source_tier"] not in VALID_SOURCE_TIERS:
            raise CorpusValidationError(
                f"{path.name}: document {doc['doc_id']} has invalid source_tier "
                f"{doc['source_tier']!r} (must be one of {sorted(VALID_SOURCE_TIERS)})"
            )
        doc_ids.add(doc["doc_id"])

    seen_chunk_ids = set()
    for chunk in chunks:
        missing = [f for f in REQUIRED_CHUNK_FIELDS if not chunk.get(f)]
        if missing:
            raise CorpusValidationError(f"{path.name}: chunk missing {missing}: {chunk}")
        if chunk["chunk_id"] in seen_chunk_ids:
            raise CorpusValidationError(f"{path.name}: duplicate chunk_id {chunk['chunk_id']}")
        seen_chunk_ids.add(chunk["chunk_id"])
        if chunk["doc_id"] not in doc_ids:
            raise CorpusValidationError(
                f"{path.name}: chunk {chunk['chunk_id']} references unknown doc_id {chunk['doc_id']!r}"
            )

    return {"documents": documents, "chunks": chunks}


def load_all_corpora(directory: Path = CORPUS_DIR) -> Dict[str, list]:
    documents: List[dict] = []
    chunks: List[dict] = []
    for path in sorted(directory.glob("*.json")):
        parsed = load_corpus_file(path)
        documents.extend(parsed["documents"])
        chunks.extend(parsed["chunks"])
    return {"documents": documents, "chunks": chunks}


def ingest_into_db(directory: Path = CORPUS_DIR) -> Dict[str, int]:
    """
    Load and validate every corpus file in `directory`, then upsert into
    Postgres. Returns counts for the caller to report. Imports db.persistence
    lazily so this module stays importable (e.g. for pure validation/tests)
    without requiring a live database connection.
    """
    from db import persistence as db

    parsed = load_all_corpora(directory)
    for doc in parsed["documents"]:
        db.upsert_regulatory_document(doc)
    for chunk in parsed["chunks"]:
        db.upsert_regulatory_chunk(chunk)
    return {"documents": len(parsed["documents"]), "chunks": len(parsed["chunks"])}
