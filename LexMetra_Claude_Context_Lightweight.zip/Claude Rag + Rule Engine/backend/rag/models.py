"""
Data contracts for the RAG subsystem. See CLAUDE MASTERPROMPT.txt sections
18 (query routing) and 19 (response contract) - these types implement both
directly, field-for-field.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class QueryType(str, Enum):
    """Section 18's query taxonomy, used to route retrieval and framing."""

    LEGAL_EXPLANATION = "LEGAL_EXPLANATION"
    RULE_LOOKUP = "RULE_LOOKUP"
    APPLICABILITY_LOOKUP = "APPLICABILITY_LOOKUP"
    THRESHOLD_LOOKUP = "THRESHOLD_LOOKUP"
    AMENDMENT_LOOKUP = "AMENDMENT_LOOKUP"
    PRODUCT_COMPLIANCE_EXPLANATION = "PRODUCT_COMPLIANCE_EXPLANATION"
    CONSUMER_QUESTION = "CONSUMER_QUESTION"
    INSPECTOR_QUESTION = "INSPECTOR_QUESTION"
    REGULATORY_COMPARISON = "REGULATORY_COMPARISON"


class GroundingStatus(str, Enum):
    #: The answer is built entirely from retrieved, cited chunks.
    GROUNDED = "GROUNDED"
    #: Nothing in the knowledge base cleared the relevance threshold.
    #: Section 19: "If the required information is not in the authoritative
    #: knowledge base... do not silently answer from model memory."
    NOT_FOUND_IN_KNOWLEDGE_BASE = "NOT_FOUND_IN_KNOWLEDGE_BASE"
    #: The question asks RAG to do something only the deterministic rule
    #: engine may do (section 14: "RAG does NOT answer: Is this product
    #: legally compliant?"). No retrieval-based answer is attempted at all.
    DECISION_OUT_OF_SCOPE = "DECISION_OUT_OF_SCOPE"


@dataclass
class RetrievalHit:
    chunk_id: str
    doc_id: str
    text: str
    source_citation: str
    module: str
    score: float
    rule_id: Optional[str] = None
    rule_version_id: Optional[str] = None
    effective_from: Optional[str] = None
    effective_to: Optional[str] = None
    chapter: Optional[str] = None
    rule_no: Optional[str] = None
    subrule: Optional[str] = None
    clause: Optional[str] = None


@dataclass
class Citation:
    document: str
    rule_reference: Optional[str]
    source_citation: str
    effective_from: Optional[str]
    effective_to: Optional[str]


@dataclass
class RagResponse:
    """
    Section 19's response contract, implemented field-for-field:
        answer, query_type, module, sources, rule_ids, effective_date,
        retrieval_hits, confidence, grounding_status, citation, warning
    """

    answer: str
    query_type: QueryType
    module: Optional[str]
    sources: List[str]
    rule_ids: List[str]
    effective_date: Optional[str]
    retrieval_hits: List[RetrievalHit]
    confidence: float
    grounding_status: GroundingStatus
    citations: List[Citation] = field(default_factory=list)
    warning: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "answer": self.answer,
            "query_type": self.query_type.value,
            "module": self.module,
            "sources": self.sources,
            "rule_ids": self.rule_ids,
            "effective_date": self.effective_date,
            "retrieval_hits": [
                {
                    "chunk_id": h.chunk_id,
                    "doc_id": h.doc_id,
                    "rule_id": h.rule_id,
                    "rule_version_id": h.rule_version_id,
                    "score": round(h.score, 4),
                    "text": h.text,
                    "source_citation": h.source_citation,
                    "module": h.module,
                    "effective_from": h.effective_from,
                    "effective_to": h.effective_to,
                    "chapter": h.chapter,
                    "rule_no": h.rule_no,
                    "subrule": h.subrule,
                    "clause": h.clause,
                }
                for h in self.retrieval_hits
            ],
            "confidence": round(self.confidence, 4),
            "grounding_status": self.grounding_status.value,
            "citations": [
                {
                    "document": c.document,
                    "rule_reference": c.rule_reference,
                    "source_citation": c.source_citation,
                    "effective_from": c.effective_from,
                    "effective_to": c.effective_to,
                }
                for c in self.citations
            ],
            "warning": self.warning,
        }
