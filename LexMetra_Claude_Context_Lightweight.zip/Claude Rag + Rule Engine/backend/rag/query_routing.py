"""
Query routing (CLAUDE MASTERPROMPT.txt section 18) and the RAG/rule-engine
boundary (section 14).

CLASSIFICATION IS A HEURISTIC, NOT AN ML MODEL. This sandbox cannot reach any
LLM API (see embeddings.py's connectivity test), so there is no tested path
to an LLM-based classifier here. `classify_query()` is keyword/pattern
matching - honest about being an MVP, with a clean seam
(QueryClassifier.classify) a deployment with real API access could swap for
an LLM call without touching any caller.

THE SAFETY GUARD IS NOT PART OF THE CLASSIFIER. `is_compliance_decision_request()`
is a separate, independent function that service.py calls BEFORE routing or
retrieval, not one branch among the nine QueryType values. Section 14 is
unambiguous: "RAG does NOT answer: Is this product legally compliant? That
final answer belongs to the deterministic rule engine." A misclassification
that lets a compliance question slip through as, say, RULE_LOOKUP must not be
enough to bypass this - the guard runs regardless of what classify_query()
decides.
"""

from __future__ import annotations

import re

from rag.models import QueryType

# Deliberately narrow and literal rather than clever: false negatives here
# (a compliance question that slips through as e.g. RULE_LOOKUP) are the
# dangerous failure mode, not false positives (an explanatory question that
# gets redirected unnecessarily - annoying, not unsafe). See docs above.
_COMPLIANCE_DECISION_PATTERNS = [
    r"\bis\s+(this|it|my|the)\s+(product|package|packaging|label|item)?\s*(legally\s+)?(compliant|legal)\b",
    r"\bdoes\s+(this|it|my|the)\s+(product|package|packaging|label)?\s*comply\b",
    r"\bwill\s+(this|it)\s+pass\b",
    r"\bcan\s+i\s+(legally\s+)?sell\s+(this|it)\b",
    r"\bis\s+(this|my)\s+(package|packaging|label)\s+(compliant|legal|ok\s+to\s+sell|fine)\b",
    r"\bam\s+i\s+(compliant|violating|breaking\s+the\s+law)\b",
    r"\bwould\s+(this|it)\s+(fail|pass)\s+(an?\s+)?inspection\b",
]

_AMENDMENT_PATTERNS = [
    r"\bamend", r"\bchanged?\b", r"\bnew rule\b", r"\bupdated\b", r"\bused to be\b",
    r"\bwhen did\b.*\bchange\b",
]
_THRESHOLD_PATTERNS = [
    r"\bminimum\b", r"\bmaximum\b", r"\bthreshold\b", r"\bhow (much|many|large|small)\b",
    r"\bwhat size\b", r"\bmm\b", r"\bcm2\b", r"\bheight\b",
]
_RULE_LOOKUP_PATTERNS = [r"\bwhich rule\b", r"\bwhat rule\b", r"\brule number\b", r"\bcite\b", r"\bwhich section\b"]
_APPLICABILITY_PATTERNS = [
    r"\bdoes this apply\b", r"\bis this exempt\b", r"\bapplicable to\b",
    r"\bdo i need to\b", r"\bam i required\b", r"\brequired for\b",
]
_COMPARISON_PATTERNS = [r"\bdifference between\b", r"\bcompare\b", r"\bversus\b", r"\bvs\.?\b"]
_INSPECTOR_PATTERNS = [r"\bduring inspection\b", r"\bhow do i (verify|measure|check)\b", r"\bevidence needed\b", r"\binspector\b"]
_CONSUMER_PATTERNS = [r"\bas a (customer|consumer|shopper)\b", r"\bcan i return\b", r"\bwhat can i do if\b", r"\bwho do i complain\b"]


def _matches_any(patterns, text: str) -> bool:
    return any(re.search(p, text) for p in patterns)


def is_compliance_decision_request(question: str) -> bool:
    """
    True if the question is asking RAG to make (or imply) a PASS/FAIL
    compliance determination, which only the deterministic rule engine may
    do. service.py checks this FIRST, before any retrieval or classification.
    """
    text = question.lower().strip()
    return _matches_any(_COMPLIANCE_DECISION_PATTERNS, text)


def classify_query(question: str) -> QueryType:
    text = question.lower().strip()

    # Checked first even though service.py also guards this independently:
    # classify_query() should never itself claim a compliance question is
    # "just" a RULE_LOOKUP or similar - the type it reports must be honest.
    if is_compliance_decision_request(text):
        return QueryType.PRODUCT_COMPLIANCE_EXPLANATION
    if _matches_any(_AMENDMENT_PATTERNS, text):
        return QueryType.AMENDMENT_LOOKUP
    if _matches_any(_COMPARISON_PATTERNS, text):
        return QueryType.REGULATORY_COMPARISON
    if _matches_any(_THRESHOLD_PATTERNS, text):
        return QueryType.THRESHOLD_LOOKUP
    if _matches_any(_RULE_LOOKUP_PATTERNS, text):
        return QueryType.RULE_LOOKUP
    if _matches_any(_APPLICABILITY_PATTERNS, text):
        return QueryType.APPLICABILITY_LOOKUP
    if _matches_any(_INSPECTOR_PATTERNS, text):
        return QueryType.INSPECTOR_QUESTION
    if _matches_any(_CONSUMER_PATTERNS, text):
        return QueryType.CONSUMER_QUESTION
    return QueryType.LEGAL_EXPLANATION
