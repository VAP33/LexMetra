"""
Hybrid retrieval (CLAUDE MASTERPROMPT.txt section 17).

Combines BM25 (sparse, keyword) and TF-IDF cosine similarity (this
deployment's "dense" substitute - see embeddings.py) via Reciprocal Rank
Fusion, after a metadata PRE-filter (module, effective-date window). This is
an in-process index built from Postgres content at construction time, not a
separate vector-database service - see db/schema.sql's comment on why.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Dict, List, Optional, Sequence

from rag.embeddings import EmbeddingProvider, TfidfEmbeddingProvider
from rag.models import RetrievalHit

_TOKEN_RE = re.compile(r"[a-z0-9]+")

# The same stopword list scikit-learn's TfidfVectorizer(stop_words="english")
# uses is applied here too. Without this, BM25 scoring - which has no
# built-in stopword awareness - lets ultra-common connector words ("is",
# "the", "of", "a") dominate the score for ANY query, since they appear in
# nearly every chunk. Measured directly: an off-topic query ("airspeed
# velocity of an unladen swallow") cleared the BM25 relevance floor purely
# from "is"/"the"/"of"/"an" overlap before this fix, despite zero overlap on
# any actual content word.
_STOPWORDS = frozenset("""
a about above after again against all am an and any are aren't as at be
because been before being below between both but by can't cannot could
couldn't did didn't do does doesn't doing don't down during each few for
from further had hadn't has hasn't have haven't having he he'd he'll he's
her here here's hers herself him himself his how how's i i'd i'll i'm i've
if in into is isn't it it's its itself let's me more most mustn't my myself
no nor not of off on once only or other ought our ours ourselves out over
own same shan't she she'd she'll she's should shouldn't so some such than
that that's the their theirs them themselves then there there's these they
they'd they'll they're they've this those through to too under until up
very was wasn't we we'd we'll we're we've were weren't what what's when
when's where where's which while who who's whom why why's with won't would
wouldn't you you'd you'll you're you've your yours yourself yourselves
""".split())


def _tokenize(text: str) -> List[str]:
    return [t for t in _TOKEN_RE.findall(text.lower()) if t not in _STOPWORDS]


def _covers(chunk: dict, as_of: date) -> bool:
    effective_from = chunk.get("effective_from")
    effective_to = chunk.get("effective_to")
    # Postgres DATE columns already deserialize to datetime.date via psycopg2;
    # accept ISO strings too so this also works against hand-built test
    # fixtures that pass plain dicts.
    if isinstance(effective_from, str):
        effective_from = date.fromisoformat(effective_from)
    if isinstance(effective_to, str):
        effective_to = date.fromisoformat(effective_to)
    if effective_from and as_of < effective_from:
        return False
    if effective_to and as_of >= effective_to:
        return False
    return True


@dataclass
class RetrievalConfig:
    top_k: int = 5
    rrf_k: int = 60
    # A chunk must be found by at least one method's tokenizable overlap to
    # be considered "found" at all - see HybridRetriever.search()'s
    # min_hits behaviour. This is what lets the caller distinguish "found
    # something, just ranked low" from "found genuinely nothing", which
    # matters for NOT_FOUND_IN_KNOWLEDGE_BASE (service.py).
    min_bm25_score: float = 0.01
    # Same idea for the "dense" side. TF-IDF cosine similarities for short
    # regulatory queries against this corpus are usually well above 0.2 for
    # a genuine topical match and indistinguishable from 0 for an unrelated
    # one (an out-of-vocabulary query produces an all-zero TF-IDF vector) -
    # see HybridRetriever.search()'s relevance-floor comment.
    min_cosine_score: float = 0.10


class HybridRetriever:
    def __init__(
        self,
        chunks: Sequence[dict],
        embedding_provider: Optional[EmbeddingProvider] = None,
        config: Optional[RetrievalConfig] = None,
    ):
        from rank_bm25 import BM25Okapi

        self.chunks: List[dict] = list(chunks)
        self.config = config or RetrievalConfig()
        self._by_id: Dict[str, dict] = {c["chunk_id"]: c for c in self.chunks}

        tokenized = [_tokenize(c["text"]) for c in self.chunks]
        self._bm25 = BM25Okapi(tokenized) if tokenized else None

        self.embedding_provider = embedding_provider or TfidfEmbeddingProvider()
        self._doc_vectors = None
        if self.chunks and isinstance(self.embedding_provider, TfidfEmbeddingProvider):
            self.embedding_provider.fit([c["text"] for c in self.chunks])
            self._doc_vectors = self.embedding_provider.embed([c["text"] for c in self.chunks])
        elif self.chunks and self.embedding_provider.is_available():
            self._doc_vectors = self.embedding_provider.embed([c["text"] for c in self.chunks])

    def _filtered_indices(
        self, module: Optional[str], as_of: Optional[date], rule_id: Optional[str],
    ) -> List[int]:
        indices = []
        for i, chunk in enumerate(self.chunks):
            if module and chunk.get("module") != module:
                continue
            if rule_id and chunk.get("rule_id") != rule_id:
                continue
            if as_of is not None and not _covers(chunk, as_of):
                continue
            indices.append(i)
        return indices

    def search(
        self,
        query: str,
        module: Optional[str] = None,
        as_of: Optional[date] = None,
        rule_id: Optional[str] = None,
        top_k: Optional[int] = None,
    ) -> List[RetrievalHit]:
        top_k = top_k or self.config.top_k
        candidate_idx = self._filtered_indices(module, as_of, rule_id)
        if not candidate_idx or self._bm25 is None:
            return []

        query_tokens = _tokenize(query)
        bm25_scores_all = self._bm25.get_scores(query_tokens)
        bm25_ranked = sorted(candidate_idx, key=lambda i: bm25_scores_all[i], reverse=True)

        cosine_scores: Dict[int, float] = {}
        cosine_ranked = candidate_idx
        if self._doc_vectors is not None:
            cosine_scores = self._cosine_scores(query, candidate_idx)
            cosine_ranked = sorted(candidate_idx, key=lambda i: cosine_scores.get(i, 0.0), reverse=True)

        # ABSOLUTE relevance floor, checked BEFORE fusion. Reciprocal Rank
        # Fusion is a RANKING signal, not a relevance signal: it will always
        # produce a "rank 1" candidate among whatever survived the metadata
        # filter, even when every raw score is ~0 (a totally unrelated
        # query still ends up ranked first among some chunk, with a fused
        # score indistinguishable from a genuinely strong match). Measured
        # directly: an off-topic query ("airspeed velocity of an unladen
        # swallow") against this corpus produced RRF-normalised
        # confidence=0.98 before this floor was added. At least one of the
        # two underlying methods must clear its own absolute floor, or
        # nothing is returned at all - see service.py's NOT_FOUND_IN_KNOWLEDGE_BASE.
        best_bm25 = max((bm25_scores_all[i] for i in candidate_idx), default=0.0)
        best_cosine = max(cosine_scores.values(), default=0.0)
        if best_bm25 < self.config.min_bm25_score and best_cosine < self.config.min_cosine_score:
            return []

        # Reciprocal Rank Fusion across the two rankings.
        fused: Dict[int, float] = {}
        for rank, i in enumerate(bm25_ranked):
            fused[i] = fused.get(i, 0.0) + 1.0 / (self.config.rrf_k + rank + 1)
        for rank, i in enumerate(cosine_ranked):
            fused[i] = fused.get(i, 0.0) + 1.0 / (self.config.rrf_k + rank + 1)

        ordered = sorted(fused.items(), key=lambda kv: kv[1], reverse=True)[:top_k]
        hits: List[RetrievalHit] = []
        for idx, _fused_score in ordered:
            chunk = self.chunks[idx]
            # The externally-visible score is NOT the RRF fusion value: RRF
            # reflects rank position within the filtered candidate pool, not
            # absolute relevance, so a lone weak match that trivially ranks
            # "first" among a small pool would otherwise report a
            # misleadingly high score (measured: 0.98 for a nonsense query
            # before the relevance floor above existed). Report the
            # strongest of the two raw, bounded signals instead - this is
            # what service.py's confidence is actually built from.
            hits.append(RetrievalHit(
                chunk_id=chunk["chunk_id"],
                doc_id=chunk["doc_id"],
                text=chunk["text"],
                source_citation=chunk["source_citation"],
                module=chunk.get("module"),
                score=max(_normalize_bm25(bm25_scores_all[idx]), cosine_scores.get(idx, 0.0)),
                rule_id=chunk.get("rule_id"),
                rule_version_id=chunk.get("rule_version_id"),
                effective_from=_isoformat(chunk.get("effective_from")),
                effective_to=_isoformat(chunk.get("effective_to")),
                chapter=chunk.get("chapter"),
                rule_no=chunk.get("rule_no"),
                subrule=chunk.get("subrule"),
                clause=chunk.get("clause"),
            ))
        return hits

    def _cosine_scores(self, query: str, candidate_idx: Sequence[int]) -> Dict[int, float]:
        import numpy as np

        if isinstance(self.embedding_provider, TfidfEmbeddingProvider):
            query_vec = np.array(self.embedding_provider.embed([query])[0])
        else:
            if not self.embedding_provider.is_available():
                return {}
            query_vec = np.array(self.embedding_provider.embed([query])[0])

        scores: Dict[int, float] = {}
        for i in candidate_idx:
            doc_vec = np.array(self._doc_vectors[i])
            denom = (np.linalg.norm(query_vec) * np.linalg.norm(doc_vec)) or 1.0
            scores[i] = float(np.dot(query_vec, doc_vec) / denom)
        return scores


def _isoformat(value) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return value.isoformat()


def _normalize_bm25(raw_score: float) -> float:
    """
    Soft-saturating heuristic squash into roughly [0, 1). BM25's raw scale
    is corpus- and query-length-dependent with no fixed upper bound, so this
    is deliberately a rough monotonic transform for display/confidence
    purposes, NOT a calibrated probability.
    """
    if raw_score <= 0:
        return 0.0
    return raw_score / (raw_score + 5.0)


def build_default_retriever(module: Optional[str] = None) -> HybridRetriever:
    """
    Convenience constructor: loads chunks from Postgres via db.persistence
    and builds a retriever. Tries GeminiEmbeddingProvider first (per section
    21's instruction to use the configured GEMINI_API_KEY), falling back to
    TfidfEmbeddingProvider - loudly, not silently - if it is unavailable
    (unset key, or unreachable, as this sandbox always is; see
    embeddings.py). This mirrors config.py's existing PaddleOCR
    fail-closed-to-Tesseract pattern.
    """
    import logging

    from db import persistence as db
    from rag.embeddings import GeminiEmbeddingProvider

    logger = logging.getLogger(__name__)
    chunks = db.list_regulatory_chunks(module=module)

    provider: EmbeddingProvider = GeminiEmbeddingProvider()
    if not provider.is_available():
        logger.warning(
            "GeminiEmbeddingProvider unavailable (unset key or unreachable API) - "
            "falling back to TfidfEmbeddingProvider for RAG retrieval."
        )
        provider = TfidfEmbeddingProvider()

    return HybridRetriever(chunks, embedding_provider=provider)
