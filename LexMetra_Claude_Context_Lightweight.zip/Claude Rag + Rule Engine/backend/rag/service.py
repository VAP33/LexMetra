"""
RAG service entrypoint (CLAUDE MASTERPROMPT.txt sections 14, 19, 20).

THE BOUNDARY THIS MODULE ENFORCES (section 14):
    RAG answers:  "What rule applies?" / "What does it mean?" / "What
                  threshold applies?" / "What evidence is required?"
    RAG does NOT answer: "Is this product legally compliant?"
That final answer belongs to rule_engine.run_inspection(). answer_query()
checks query_routing.is_compliance_decision_request() FIRST, before any
retrieval happens at all - a compliance question never even reaches the
retriever, let alone gets an extractive answer synthesised for it. This is
deliberate defence in depth: even if a future change to the retriever or
classifier were wrong, a compliance question still cannot produce a
confident-sounding retrieval-based answer, because retrieval is never called
for it in the first place.

THE ANSWER IS EXTRACTIVE, NOT GENERATED. `answer` is built directly from the
text of the retrieved chunks (see _extractive_answer), not paraphrased or
synthesised by an LLM. No LLM call in this pipeline is tested in this
sandbox (see embeddings.py) - shipping an "answer" field that silently
depended on an unreachable API, or worse, on this model's own general
knowledge of Indian law instead of the retrieved corpus, would violate
section 19's "do not silently answer from model memory" outright. An
extractive answer can only ever say what is actually in the knowledge base.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from rag.models import Citation, GroundingStatus, QueryType, RagResponse
from rag.query_routing import classify_query, is_compliance_decision_request
from rag.retrieval import HybridRetriever, build_default_retriever

_COMPLIANCE_REDIRECT_ANSWER = (
    "This system cannot tell you whether a product is legally compliant - "
    "that determination is made only by the deterministic rule engine, "
    "evaluating actual evidence captured for a specific product against the "
    "rule version in force on the inspection date. To get a compliance "
    "result, run an inspection through the normal capture workflow rather "
    "than asking here. This knowledge base can still tell you what a "
    "specific rule requires, what threshold applies, or what evidence would "
    "be needed - try rephrasing as that kind of question."
)


def answer_query(
    question: str,
    module: Optional[str] = None,
    as_of_date: Optional[date] = None,
    retriever: Optional[HybridRetriever] = None,
) -> RagResponse:
    if is_compliance_decision_request(question):
        return RagResponse(
            answer=_COMPLIANCE_REDIRECT_ANSWER,
            query_type=QueryType.PRODUCT_COMPLIANCE_EXPLANATION,
            module=module,
            sources=[],
            rule_ids=[],
            effective_date=None,
            retrieval_hits=[],
            confidence=0.0,
            grounding_status=GroundingStatus.DECISION_OUT_OF_SCOPE,
            citations=[],
            warning=(
                "No retrieval was attempted for this question - it asks for a "
                "compliance decision, which is out of scope for RAG."
            ),
        )

    query_type = classify_query(question)
    resolved_as_of = as_of_date or date.today()
    retriever = retriever or build_default_retriever(module=module)

    hits = retriever.search(question, module=module, as_of=resolved_as_of)

    if not hits:
        return RagResponse(
            answer=(
                "NOT_FOUND_IN_KNOWLEDGE_BASE: no chunk in the regulatory "
                "knowledge base matched this question closely enough to answer "
                "from. This may mean the knowledge base genuinely does not "
                "cover this topic yet, not that no such rule exists - confirm "
                "with a subject-matter expert or check the rule dataset directly."
            ),
            query_type=query_type,
            module=module,
            sources=[],
            rule_ids=[],
            effective_date=resolved_as_of.isoformat(),
            retrieval_hits=[],
            confidence=0.0,
            grounding_status=GroundingStatus.NOT_FOUND_IN_KNOWLEDGE_BASE,
            citations=[],
            warning="No relevant source was found; nothing here was answered from model memory.",
        )

    # hits[0].score is already the strongest of the two bounded, raw
    # relevance signals (see retrieval.py) - not an RRF fusion value, so no
    # further rescaling is needed or appropriate here.
    confidence = hits[0].score

    citations = [
        Citation(
            document=h.doc_id,
            rule_reference=" ".join(filter(None, [h.rule_no, h.subrule, h.clause])) or None,
            source_citation=h.source_citation,
            effective_from=h.effective_from,
            effective_to=h.effective_to,
        )
        for h in hits
    ]

    return RagResponse(
        answer=_extractive_answer(hits),
        query_type=query_type,
        module=module or (hits[0].module if hits else None),
        sources=sorted({h.source_citation for h in hits}),
        rule_ids=sorted({h.rule_id for h in hits if h.rule_id}),
        effective_date=resolved_as_of.isoformat(),
        retrieval_hits=hits,
        confidence=confidence,
        grounding_status=GroundingStatus.GROUNDED,
        citations=citations,
        warning=None,
    )


def _extractive_answer(hits) -> str:
    """
    Concatenate the strongest chunk(s), verbatim, rather than paraphrase or
    generate. A second chunk is included only if it scored close to the top
    hit (otherwise it is likely a weaker/tangential match not worth
    presenting as part of the answer).
    """
    parts = [hits[0].text]
    if len(hits) > 1 and hits[0].score > 0 and hits[1].score >= 0.5 * hits[0].score:
        parts.append(hits[1].text)
    return "\n\n".join(parts)
