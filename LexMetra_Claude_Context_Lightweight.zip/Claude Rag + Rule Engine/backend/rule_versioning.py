"""
Multi-versioned rule resolution (CLAUDE MASTERPROMPT.txt section 11).

THE PROBLEM THIS SOLVES. `rules/rules.json` already carried `effective_from`
/`effective_to`/`version` fields per rule before this module existed, but
`rule_engine.load_rules()` loaded it as ONE CURRENT SNAPSHOT: exactly one
JSON object per `rule_id`, keyed straight into a dict, with a hard
`ValueError` on any repeated `rule_id`. That's version *labelling*, not
version *resolution* - the `effective_from` on e.g. `LMPC-2011-R7-2-FONT`
correctly documents that the PDP-area font-height bands took effect on
2018-01-01, but there was no PRIOR row for the flat 1mm/2mm rule that applied
before that date, and no code path that could pick the right one for a given
date even if there were. An inspection dated in 2015 would have been silently
evaluated against 2018 thresholds. This module is the resolution layer that
was missing: `rules.json` may now carry MULTIPLE objects sharing the same
`rule_id`, each covering a distinct, non-overlapping `[effective_from,
effective_to)` window, and this module picks the one that was actually in
force on a given date.

SAFETY INVARIANTS THIS MODULE ENFORCES (see CLAUDE MASTERPROMPT.txt section
2.2 and section 43 #5/#6):
  - Two versions of the same rule_id must NEVER have overlapping effective
    windows - `load_rule_history()` raises at load time if they do, rather
    than let `resolve_active_rules()` silently pick "whichever came first in
    the file" at evaluation time. A malformed dataset must fail loudly at
    startup, not quietly at inspection time.
  - A rule with NO version covering the requested date (inspecting a product
    from before LMPC 2011 existed, or a genuine gap between two rules) is
    left OUT of the resolved snapshot entirely - `rule_engine._find_rule()`
    already treats "no matching rule_id" as "this rule does not apply", which
    is the semantically correct behaviour for a rule that was not yet (or no
    longer) in force. This module never guesses the "closest" version.
  - Rule version rows themselves are NEVER edited in place once another
    session/date depends on them - only ever superseded by a new row with a
    later `effective_from`. Historical reproducibility depends entirely on
    this discipline: resolving the SAME rule_id against the SAME historical
    `as_of` date must always return the SAME row, forever. There is
    (deliberately) no code in this module that mutates a version row.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Mapping, Optional


class RuleVersioningError(ValueError):
    """Raised when rules.json's version history is internally inconsistent."""


@dataclass(frozen=True)
class RuleVersionWindow:
    rule_id: str
    effective_from: date
    effective_to: Optional[date]  # None means "still in force"

    def covers(self, as_of: date) -> bool:
        if as_of < self.effective_from:
            return False
        if self.effective_to is not None and as_of >= self.effective_to:
            return False
        return True


def _parse_date(value: Optional[str], *, rule_id: str, field: str) -> Optional[date]:
    if value is None:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError as exc:
        raise RuleVersioningError(
            f"{rule_id}: {field}={value!r} is not a valid YYYY-MM-DD date"
        ) from exc


def stable_version_id(rule: Mapping) -> Optional[str]:
    """
    A stable, human-readable identifier for exactly the version row a finding
    was evaluated against - `rule_id + "@" + effective_from` - independent of
    the free-text `version` label (which describes the amendment in prose and
    is not guaranteed unique or stably formatted). Used to stamp findings so a
    later audit can confirm the same row was used, without depending on
    `rules.json`'s current contents to do so.
    """
    rule_id = rule.get("rule_id")
    effective_from = rule.get("effective_from")
    if not rule_id or not effective_from:
        return None
    return f"{rule_id}@{effective_from}"


def load_rule_history(path: Path) -> Dict[str, List[dict]]:
    """
    Parse rules.json and group every rule object by `rule_id`, sorted by
    `effective_from`. Raises RuleVersioningError if:
      - a rule object is missing `rule_id` or `effective_from`;
      - two versions of the same rule_id have overlapping effective windows.
    Does NOT raise on a gap between two versions of the same rule_id (no
    version in force covering some interval) - a gap can be a genuine legal
    state (a requirement lapsed and was not immediately replaced), so it is
    represented, not rejected, and simply means `resolve_active_rules()` will
    omit that rule_id for a date falling in the gap.
    """
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("rules"), list):
        raise RuleVersioningError("rules.json must contain a top-level 'rules' array")

    history: Dict[str, List[dict]] = {}
    for rule in data["rules"]:
        rule_id = rule.get("rule_id")
        if not rule_id:
            raise RuleVersioningError("Every legal rule must have a rule_id")
        if not rule.get("effective_from"):
            raise RuleVersioningError(f"{rule_id}: every rule version requires effective_from")
        history.setdefault(rule_id, []).append(rule)

    for rule_id, versions in history.items():
        windows = [
            RuleVersionWindow(
                rule_id=rule_id,
                effective_from=_parse_date(v["effective_from"], rule_id=rule_id, field="effective_from"),
                effective_to=_parse_date(v.get("effective_to"), rule_id=rule_id, field="effective_to"),
            )
            for v in versions
        ]
        order = sorted(range(len(versions)), key=lambda i: windows[i].effective_from)
        versions[:] = [versions[i] for i in order]
        windows = [windows[i] for i in order]

        for i in range(len(windows) - 1):
            current, nxt = windows[i], windows[i + 1]
            current_end = current.effective_to
            if current_end is None or current_end > nxt.effective_from:
                raise RuleVersioningError(
                    f"{rule_id}: version effective {current.effective_from} "
                    f"(effective_to={current_end}) overlaps the version effective "
                    f"{nxt.effective_from}. Two versions of the same rule must never "
                    "both claim to be in force on the same date - fix effective_to on "
                    "the earlier version."
                )

    return history


def resolve_active_rules(history: Mapping[str, List[dict]], as_of: date) -> Dict[str, dict]:
    """
    For each rule_id, return the ONE version whose window covers `as_of`, if
    any. A rule_id with versions but none covering `as_of` is simply absent
    from the result - see module docstring on why that is correct, not a bug.
    """
    resolved: Dict[str, dict] = {}
    for rule_id, versions in history.items():
        for rule in versions:
            window = RuleVersionWindow(
                rule_id=rule_id,
                effective_from=_parse_date(rule["effective_from"], rule_id=rule_id, field="effective_from"),
                effective_to=_parse_date(rule.get("effective_to"), rule_id=rule_id, field="effective_to"),
            )
            if window.covers(as_of):
                resolved[rule_id] = rule
                break
    return resolved
