import json

import pytest

from rag.ingestion import CorpusValidationError, load_all_corpora, load_corpus_file


def _write(tmp_path, name, data):
    path = tmp_path / name
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def test_real_corpus_loads_and_validates():
    from rag.ingestion import CORPUS_DIR

    parsed = load_all_corpora(CORPUS_DIR)
    assert len(parsed["documents"]) >= 1
    assert len(parsed["chunks"]) >= 10
    chunk_ids = [c["chunk_id"] for c in parsed["chunks"]]
    assert len(chunk_ids) == len(set(chunk_ids)), "duplicate chunk_id in real corpus"


def test_rejects_chunk_missing_required_field(tmp_path):
    path = _write(tmp_path, "bad.json", {
        "documents": [{"doc_id": "D1", "title": "T", "source_tier": "SECONDARY", "jurisdiction": "India"}],
        "chunks": [{"chunk_id": "C1", "doc_id": "D1", "module": "LMPC"}],  # missing effective_from/text/source_citation
    })
    with pytest.raises(CorpusValidationError):
        load_corpus_file(path)


def test_rejects_chunk_with_unknown_doc_id(tmp_path):
    path = _write(tmp_path, "bad.json", {
        "documents": [{"doc_id": "D1", "title": "T", "source_tier": "SECONDARY", "jurisdiction": "India"}],
        "chunks": [{
            "chunk_id": "C1", "doc_id": "DOES-NOT-EXIST", "module": "LMPC",
            "effective_from": "2020-01-01", "text": "x", "source_citation": "y",
        }],
    })
    with pytest.raises(CorpusValidationError, match="unknown doc_id"):
        load_corpus_file(path)


def test_rejects_invalid_source_tier(tmp_path):
    path = _write(tmp_path, "bad.json", {
        "documents": [{"doc_id": "D1", "title": "T", "source_tier": "MADE_UP_TIER", "jurisdiction": "India"}],
        "chunks": [],
    })
    with pytest.raises(CorpusValidationError, match="source_tier"):
        load_corpus_file(path)


def test_rejects_duplicate_chunk_id(tmp_path):
    chunk = {
        "chunk_id": "C1", "doc_id": "D1", "module": "LMPC",
        "effective_from": "2020-01-01", "text": "x", "source_citation": "y",
    }
    path = _write(tmp_path, "bad.json", {
        "documents": [{"doc_id": "D1", "title": "T", "source_tier": "SECONDARY", "jurisdiction": "India"}],
        "chunks": [chunk, dict(chunk)],
    })
    with pytest.raises(CorpusValidationError, match="duplicate chunk_id"):
        load_corpus_file(path)
