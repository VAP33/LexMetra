"""
Tests for rag/query_routing.py. The compliance-decision guard tests are the
most important tests in the whole RAG subsystem - see
rag/service.py's module docstring on why a missed compliance question is
the dangerous failure mode. Every one of these was actually run against a
live retriever at least once during development; two of the guard patterns
below were added specifically because an earlier, narrower regex missed
"Is this product legally compliant?" and "Does my product comply with
regulations?" when tested end-to-end - this file exists so that exact
regression can never silently come back.
"""

import pytest

from rag.models import QueryType
from rag.query_routing import classify_query, is_compliance_decision_request


@pytest.mark.parametrize("question", [
    "Is this product legally compliant?",
    "is this product compliant",
    "Does my product comply with regulations?",
    "Will this pass inspection?",
    "Can I legally sell this?",
    "Is my package compliant?",
    "Am I violating the law?",
    "Would this fail an inspection?",
    "Is it legal?",
])
def test_compliance_decision_requests_are_detected(question):
    assert is_compliance_decision_request(question) is True
    assert classify_query(question) == QueryType.PRODUCT_COMPLIANCE_EXPLANATION


@pytest.mark.parametrize("question", [
    "What is the minimum letter height for declarations?",
    "What does Rule 6(11) require?",
    "What is a wholesale package?",
    "When did the unit-sale-price amendment take effect?",
    "What is the difference between a retail and wholesale package?",
    "As a consumer, who do I complain to about a mislabelled product?",
])
def test_non_compliance_questions_are_not_flagged(question):
    assert is_compliance_decision_request(question) is False


def test_amendment_lookup_classification():
    assert classify_query("When did this rule change?") == QueryType.AMENDMENT_LOOKUP


def test_threshold_lookup_classification():
    assert classify_query("What is the minimum font size required?") == QueryType.THRESHOLD_LOOKUP


def test_comparison_classification():
    assert classify_query("What is the difference between Rule 6 and Rule 7?") == QueryType.REGULATORY_COMPARISON


def test_rule_lookup_classification():
    assert classify_query("Which rule covers wholesale packages?") == QueryType.RULE_LOOKUP


def test_applicability_lookup_classification():
    assert classify_query("Does this apply to imported goods?") == QueryType.APPLICABILITY_LOOKUP


def test_default_falls_back_to_legal_explanation():
    assert classify_query("Explain the Principal Display Panel concept.") == QueryType.LEGAL_EXPLANATION
