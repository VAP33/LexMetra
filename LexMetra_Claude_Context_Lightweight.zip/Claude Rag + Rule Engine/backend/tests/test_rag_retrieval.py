"""
Tests for rag/retrieval.py's HybridRetriever, using a small synthetic corpus
so these are fast and independent of Postgres. The real corpus is exercised
separately in test_rag_service.py's DB-backed tests.
"""

from datetime import date

from rag.retrieval import HybridRetriever, RetrievalConfig


def _chunk(chunk_id, text, effective_from="2011-04-01", effective_to=None,
           module="LMPC", rule_id=None):
    return {
        "chunk_id": chunk_id, "doc_id": "DOC-1", "text": text,
        "source_citation": f"Test source for {chunk_id}",
        "module": module, "rule_id": rule_id, "rule_version_id": None,
        "effective_from": effective_from, "effective_to": effective_to,
        "chapter": None, "rule_no": None, "subrule": None, "clause": None,
    }


CHUNKS = [
    _chunk("old-font", "The minimum letter height for declarations is 1 millimetre under the original rule.",
           effective_from="2011-04-01", effective_to="2018-01-01", rule_id="R-FONT"),
    _chunk("new-font", "The minimum letter height for declarations is banded by principal display panel area under the amended rule.",
           effective_from="2018-01-01", effective_to=None, rule_id="R-FONT"),
    _chunk("wholesale", "A wholesale package is intended for sale to an intermediary rather than a retail consumer."),
    _chunk("unrelated", "Consumer care contact details must include a phone number and address."),
]


def test_finds_lexically_relevant_chunk():
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search("What is the minimum letter height requirement?", as_of=date(2026, 1, 1))
    assert hits, "expected at least one hit"
    assert hits[0].chunk_id == "new-font"


def test_effective_date_filtering_picks_correct_version():
    retriever = HybridRetriever(CHUNKS)

    old_hits = retriever.search("minimum letter height for declarations", as_of=date(2015, 1, 1))
    new_hits = retriever.search("minimum letter height for declarations", as_of=date(2026, 1, 1))

    assert old_hits[0].chunk_id == "old-font"
    assert new_hits[0].chunk_id == "new-font"


def test_date_in_gap_excludes_chunk_entirely():
    # As_of before 2011-04-01: neither font version was in force yet.
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search("minimum letter height for declarations", as_of=date(2005, 1, 1))
    chunk_ids = {h.chunk_id for h in hits}
    assert "old-font" not in chunk_ids
    assert "new-font" not in chunk_ids


def test_module_filter_excludes_other_modules():
    chunks = CHUNKS + [_chunk("other-module", "Minimum letter height for FSSAI labels.", module="FSSAI")]
    retriever = HybridRetriever(chunks)
    hits = retriever.search("minimum letter height", module="LMPC", as_of=date(2026, 1, 1))
    assert all(h.module == "LMPC" for h in hits)


def test_nonsense_query_returns_no_hits():
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search("quantum entanglement of exotic mesons", as_of=date(2026, 1, 1))
    assert hits == []


def test_stopword_only_query_does_not_trivially_match_everything():
    # Regression test: before stopwords were stripped from BM25 tokenization,
    # queries dominated by "is/the/of/an" cleared the relevance floor purely
    # from connector-word overlap, regardless of actual topical content.
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search("what is the of an it", as_of=date(2026, 1, 1))
    assert hits == []


def test_empty_corpus_returns_no_hits():
    retriever = HybridRetriever([])
    assert retriever.search("anything at all") == []


def test_rule_id_filter():
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search(
        "letter height", rule_id="R-FONT", as_of=date(2026, 1, 1),
    )
    assert all(h.rule_id == "R-FONT" for h in hits)
    assert "wholesale" not in {h.chunk_id for h in hits}


def test_scores_are_bounded_between_zero_and_one():
    retriever = HybridRetriever(CHUNKS)
    hits = retriever.search("minimum letter height for declarations", as_of=date(2026, 1, 1))
    for h in hits:
        assert 0.0 <= h.score <= 1.0
