"""
Tests for rag/service.py against the REAL ingested corpus (backend/rag/corpus/
lmpc_corpus.json) via Postgres - not a synthetic fixture. These require the
corpus to have been seeded (tools/seed_rag_corpus.py) into the test database;
see conftest.py's db_ready fixture for how that's ensured.
"""

from datetime import date

import pytest

from rag.ingestion import ingest_into_db
from rag.models import GroundingStatus, QueryType
from rag.retrieval import build_default_retriever
from rag.service import answer_query


@pytest.fixture(scope="module")
def lmpc_retriever(db_ready):
    ingest_into_db()  # idempotent (ON CONFLICT DO UPDATE) - safe to call repeatedly
    return build_default_retriever(module="LMPC")


def test_response_contract_has_all_required_fields(lmpc_retriever):
    r = answer_query(
        "What is the minimum letter height for declarations?",
        module="LMPC", as_of_date=date(2026, 1, 1), retriever=lmpc_retriever,
    )
    d = r.to_dict()
    for field in (
        "answer", "query_type", "module", "sources", "rule_ids", "effective_date",
        "retrieval_hits", "confidence", "grounding_status", "citations", "warning",
    ):
        assert field in d, f"missing required response field: {field}"


def test_compliance_question_never_reaches_retrieval(lmpc_retriever):
    r = answer_query(
        "Is my product legally compliant?",
        module="LMPC", retriever=lmpc_retriever,
    )
    assert r.grounding_status == GroundingStatus.DECISION_OUT_OF_SCOPE
    assert r.query_type == QueryType.PRODUCT_COMPLIANCE_EXPLANATION
    assert r.retrieval_hits == []
    assert r.rule_ids == []
    assert r.confidence == 0.0
    assert "deterministic rule engine" in r.answer


def test_historical_font_rule_retrieved_for_historical_date(lmpc_retriever):
    r = answer_query(
        "What is the minimum letter height required for declarations?",
        module="LMPC", as_of_date=date(2015, 6, 1), retriever=lmpc_retriever,
    )
    assert r.grounding_status == GroundingStatus.GROUNDED
    assert r.retrieval_hits[0].chunk_id == "LMPC-CHUNK-R7-FONT-OLD"
    assert r.retrieval_hits[0].rule_version_id == "LMPC-2011-R7-2-FONT@2011-04-01"
    assert r.effective_date == "2015-06-01"


def test_current_font_rule_retrieved_for_current_date(lmpc_retriever):
    r = answer_query(
        "What is the minimum letter height required for declarations?",
        module="LMPC", as_of_date=date(2026, 9, 11), retriever=lmpc_retriever,
    )
    assert r.retrieval_hits[0].chunk_id == "LMPC-CHUNK-R7-FONT-NEW"
    assert r.retrieval_hits[0].rule_version_id == "LMPC-2011-R7-2-FONT@2018-01-01"


def test_unit_sale_price_history_resolved_by_date(lmpc_retriever):
    before = answer_query(
        "Is a unit sale price declaration required?",
        module="LMPC", as_of_date=date(2022, 1, 1), retriever=lmpc_retriever,
    )
    after = answer_query(
        "Is a unit sale price declaration required?",
        module="LMPC", as_of_date=date(2024, 1, 1), retriever=lmpc_retriever,
    )
    assert before.retrieval_hits[0].chunk_id == "LMPC-CHUNK-R6-11-UNIT-PRICE-OLD"
    assert after.retrieval_hits[0].chunk_id == "LMPC-CHUNK-R6-11-UNIT-PRICE-NEW"


def test_citation_carries_rule_reference_and_effective_date(lmpc_retriever):
    r = answer_query(
        "What is the minimum letter height for declarations?",
        module="LMPC", as_of_date=date(2026, 1, 1), retriever=lmpc_retriever,
    )
    assert r.citations, "expected at least one citation"
    top = r.citations[0]
    assert top.source_citation
    assert top.effective_from is not None


def test_off_topic_question_is_not_found_not_hallucinated(lmpc_retriever):
    r = answer_query(
        "What is the airspeed velocity of an unladen swallow?",
        module="LMPC", retriever=lmpc_retriever,
    )
    assert r.grounding_status == GroundingStatus.NOT_FOUND_IN_KNOWLEDGE_BASE
    assert r.confidence == 0.0
    assert r.rule_ids == []
    assert "NOT_FOUND_IN_KNOWLEDGE_BASE" in r.answer


def test_rule_id_cross_links_to_rule_engine_dataset(lmpc_retriever):
    """
    The whole point of stamping rule_id/rule_version_id onto RAG chunks: a
    citation for the font-height rule must use the EXACT SAME identifiers
    rule_engine.py's own versioned dataset uses, so the two subsystems can be
    shown to agree rather than silently drift apart.
    """
    import rule_versioning
    from pathlib import Path

    r = answer_query(
        "What is the minimum letter height for declarations?",
        module="LMPC", as_of_date=date(2026, 1, 1), retriever=lmpc_retriever,
    )
    rules_path = Path(__file__).resolve().parent.parent.parent / "rules" / "rules.json"
    history = rule_versioning.load_rule_history(rules_path)
    active = rule_versioning.resolve_active_rules(history, date(2026, 1, 1))
    engine_version_id = rule_versioning.stable_version_id(active["LMPC-2011-R7-2-FONT"])

    assert r.retrieval_hits[0].rule_version_id == engine_version_id
