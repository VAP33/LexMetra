"""
Unit tests for rule_versioning.py — the version-resolution layer behind
CLAUDE MASTERPROMPT.txt section 11 ("multi-versioned rule engine").
"""

import json
from datetime import date
from pathlib import Path

import pytest

import rule_versioning as rv


def _write_rules(tmp_path, rules):
    path = tmp_path / "rules.json"
    path.write_text(json.dumps({"rules": rules}), encoding="utf-8")
    return path


def test_load_rule_history_groups_by_rule_id_and_sorts(tmp_path):
    path = _write_rules(tmp_path, [
        {"rule_id": "R1", "effective_from": "2020-01-01", "effective_to": "2021-01-01", "label": "old"},
        {"rule_id": "R1", "effective_from": "2021-01-01", "effective_to": None, "label": "new"},
        {"rule_id": "R2", "effective_from": "2019-06-01", "effective_to": None, "label": "only"},
    ])
    history = rv.load_rule_history(path)
    assert set(history.keys()) == {"R1", "R2"}
    assert [r["label"] for r in history["R1"]] == ["old", "new"]  # sorted oldest-first
    assert len(history["R2"]) == 1


def test_resolve_active_rules_picks_the_window_covering_as_of(tmp_path):
    path = _write_rules(tmp_path, [
        {"rule_id": "R1", "effective_from": "2020-01-01", "effective_to": "2021-01-01", "label": "old"},
        {"rule_id": "R1", "effective_from": "2021-01-01", "effective_to": None, "label": "new"},
    ])
    history = rv.load_rule_history(path)

    assert rv.resolve_active_rules(history, date(2020, 6, 1))["R1"]["label"] == "old"
    # effective_to is exclusive: the boundary date itself belongs to the NEW version.
    assert rv.resolve_active_rules(history, date(2021, 1, 1))["R1"]["label"] == "new"
    assert rv.resolve_active_rules(history, date(2020, 12, 31))["R1"]["label"] == "old"


def test_date_before_earliest_version_leaves_rule_unresolved_not_guessed(tmp_path):
    # A date before LMPC 2011 even existed must not silently borrow the
    # earliest known version - the rule simply was not in force yet.
    path = _write_rules(tmp_path, [
        {"rule_id": "R1", "effective_from": "2020-01-01", "effective_to": None, "label": "only"},
    ])
    history = rv.load_rule_history(path)
    active = rv.resolve_active_rules(history, date(2010, 1, 1))
    assert "R1" not in active


def test_gap_between_versions_leaves_rule_unresolved(tmp_path):
    # A genuine gap (rule lapsed, no replacement yet) is represented, not an
    # error, and a date inside it correctly resolves to "not in force."
    path = _write_rules(tmp_path, [
        {"rule_id": "R1", "effective_from": "2020-01-01", "effective_to": "2021-01-01", "label": "old"},
        {"rule_id": "R1", "effective_from": "2022-01-01", "effective_to": None, "label": "new"},
    ])
    history = rv.load_rule_history(path)
    assert "R1" not in rv.resolve_active_rules(history, date(2021, 6, 1))
    assert rv.resolve_active_rules(history, date(2020, 6, 1))["R1"]["label"] == "old"
    assert rv.resolve_active_rules(history, date(2022, 6, 1))["R1"]["label"] == "new"


def test_overlapping_versions_raise_at_load_time(tmp_path):
    # This is the safety-critical case: two versions of the same rule must
    # never both claim a given date. Must fail loudly at load, not silently
    # at evaluation (CLAUDE MASTERPROMPT.txt section 57, "No Silent Fallbacks").
    path = _write_rules(tmp_path, [
        {"rule_id": "R1", "effective_from": "2020-01-01", "effective_to": "2021-06-01", "label": "old"},
        {"rule_id": "R1", "effective_from": "2021-01-01", "effective_to": None, "label": "new"},
    ])
    with pytest.raises(rv.RuleVersioningError, match="overlaps"):
        rv.load_rule_history(path)


def test_missing_effective_from_raises(tmp_path):
    path = _write_rules(tmp_path, [{"rule_id": "R1", "effective_to": None}])
    with pytest.raises(rv.RuleVersioningError, match="effective_from"):
        rv.load_rule_history(path)


def test_missing_rule_id_raises(tmp_path):
    path = _write_rules(tmp_path, [{"effective_from": "2020-01-01"}])
    with pytest.raises(rv.RuleVersioningError, match="rule_id"):
        rv.load_rule_history(path)


def test_stable_version_id_format():
    rule = {"rule_id": "LMPC-2011-R7-2-FONT", "effective_from": "2018-01-01"}
    assert rv.stable_version_id(rule) == "LMPC-2011-R7-2-FONT@2018-01-01"
    assert rv.stable_version_id({"rule_id": "R1"}) is None
    assert rv.stable_version_id({"effective_from": "2018-01-01"}) is None


def test_real_rules_json_has_no_overlapping_versions():
    """
    Smoke test against the actual production rules/rules.json: this is the
    load-time validation that would catch a real data-authoring mistake
    (e.g. a new amendment added with the wrong effective_to on the version
    it supersedes) before it ever reaches an inspection.
    """
    path = Path(__file__).resolve().parent.parent.parent / "rules" / "rules.json"
    history = rv.load_rule_history(path)  # must not raise
    assert "LMPC-2011-R7-2-FONT" in history
    assert "LMPC-2011-R6-11-UNIT-PRICE" in history
    assert len(history["LMPC-2011-R7-2-FONT"]) == 2
    assert len(history["LMPC-2011-R6-11-UNIT-PRICE"]) == 2
