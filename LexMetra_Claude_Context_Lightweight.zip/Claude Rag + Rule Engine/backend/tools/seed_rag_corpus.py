#!/usr/bin/env python3
"""
Load backend/rag/corpus/*.json into Postgres (regulatory_documents,
regulatory_chunks). Run this explicitly after editing the corpus or setting
up a fresh database - it is deliberately NOT run automatically on app
startup, the same way tools/rebuild_product_index.py is a standalone step.

Usage:
    python tools/seed_rag_corpus.py
"""

from __future__ import annotations

import sys
from pathlib import Path

_BACKEND_DIR = Path(__file__).resolve().parent.parent
if str(_BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(_BACKEND_DIR))

from rag.ingestion import ingest_into_db


def main() -> None:
    counts = ingest_into_db()
    print(f"Ingested {counts['documents']} document(s), {counts['chunks']} chunk(s).")


if __name__ == "__main__":
    main()
