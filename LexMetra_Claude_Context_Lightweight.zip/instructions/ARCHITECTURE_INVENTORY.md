# ARCHITECTURE INVENTORY
## SIH 2026 — Problem Statement 26034
### AI-Powered Legal Metrology Packaged Commodity Compliance Platform
**Inventory Date:** 2026-09-08  
**Repository Branch:** `main` (commit `95fd561`)

---

## 1. Executive Summary

This inventory audits every module, contract, and specialist folder in the repository (`CLAUDE 1`, `CLAUDE 2`, `CLAUDE 4`, `CLAUDE 5`, `backend`, `frontend`, `rules`).

### Primary Architecture Baseline
The canonical backend is centered at `backend/` and frontend at `frontend/`. Specialist tracks contributed advanced subsystems:
- **CLAUDE 1 (Frontend / UX):** Provided Next.js / Vite React application in `CLAUDE 1/frontend/react-app` with complete typed contracts, real JWT auth routing, multi-surface photo capture, review queue, and pure coordinate mapping, plus static dashboard fallbacks (`dashboard.html`, `capture.html`).
- **CLAUDE 2 (Vision / OCR / Evidence):** Built orientation-aware, region-first OCR with multi-variant preprocessing, agreement detection (CORROBORATED / SINGLE_SOURCE / CONFLICTING), and numeric signature agreement in `ocr_engine.py`, `preprocess.py`, `region_detection.py`, `orientation.py`, and `ocr_extraction.py`.
- **CLAUDE 4 (Geometry / Calibration / Measurement):** Implemented classical computer vision package geometry, planar PDP detection, perspective homography rectification, coordinate mapping, and physical calibration/measurement in `CLAUDE 4/backend/geometry.py`, `CLAUDE 4/backend/calibration.py`, and 119 unit/real-photo tests.
- **CLAUDE 5 / Recovery:** Hardened evidence integrity, closed the dropped bounding-box defect, created `inspection_findings` persistence schema, and enforced Invariant 4 (conflicting evidence cap) and Invariant 17 (evidence traceability).

---

## 2. Canonical Source Tree & Specialist Allocation

| Subsystem | Canonical Path | Primary Origin | Integration Status | Notes / Gaps |
|---|---|---|---|---|
| **Legal Rule Engine** | `backend/rule_engine.py` | Canonical / Claude 5 | **TESTED** | Evaluates Rule 6, 6(11), 7(2), 8(1), 24, and Rule 3 scope. Rules 4, 5, 25, 26(b/c), 27, 31 exist in data but need evaluators. |
| **Legal Rule Data** | `rules/rules.json` | Canonical | **TESTED** | Version 2.0 with 19 rules. Needs rule-set level versioning and official verification on 13 rules. |
| **Exemption Engine** | `backend/exemption.py` | Canonical | **TESTED** | Evaluates Rule 3 exclusions, institutional/industrial sales, and Rule 26 small packs (10g/10ml). |
| **Vision / OCR Pipeline** | `backend/ocr_engine.py`, `ocr_extraction.py`, `preprocess.py`, `region_detection.py`, `orientation.py` | Claude 2 | **TESTED** | Region-first OCR with numeric-signature conflict detection. Tesseract backend active; PaddleOCR ready for deployment. |
| **Geometry & PDP** | `CLAUDE 4/backend/geometry.py` → `backend/geometry.py` | Claude 4 | **READY FOR INTEGRATION** | Contours, `approxPolyDP`, ellipse fitting, PDP candidate detection, homography rectification. |
| **Calibration & Measurement** | `CLAUDE 4/backend/calibration.py` → `backend/calibration.py` | Claude 4 | **READY FOR INTEGRATION** | Calibrate from reference object, package dimension, or user scale; computes verified/estimated mm and PDP area cm². |
| **Evidence & Captures** | `backend/capture_session.py` | Claude 5 | **TESTED** | Multi-surface capture session, field-name bridge, provenance stamping, coverage math, capture guidance. |
| **Image Quality Gate** | `backend/image_quality.py` | Canonical | **TESTED** | Classical CV blur (Laplacian), exposure, glare clipping, and text-cluster heuristic PDP estimate. |
| **Reporting (PDF)** | `backend/report.py` | Claude 5 | **TESTED** | ReportLab evidence-backed PDF generation with row-level provenance, crop references, and audit disclosures. |
| **Database & Persistence** | `backend/db/persistence.py`, `backend/db/schema.sql` | Claude 5 | **TESTED (Pure Serialization)** | PostgreSQL schema with users, sessions, captures, inspections, facts, findings, and append-only audit_log. |
| **Authentication & RBAC** | `backend/auth.py` | Claude 5 | **IMPLEMENTED** | JWT issuing/verification, bcrypt hashing, 3-tier RBAC (`inspector` < `reviewer` < `admin`). |
| **FastAPI REST API** | `backend/main.py` | Claude 5 | **IMPLEMENTED** | 18 endpoints for auth, scans, inspections, sessions, reviews, reports, audit logs. |
| **Frontend Web App** | `CLAUDE 1/frontend/react-app/` & `frontend/dashboard.html` | Claude 1 | **IMPLEMENTED** | React/TypeScript application with JWT login, multi-surface capture, review queue, and pure coordinates. |

---

## 3. Detailed Component State & Gap Analysis

### 3.1 Legal Rule Engine & Ruleset
- **Strengths:** Deterministic, non-LLM. Strictly enforces `NOT_OBSERVED != MISSING` via coverage gates; handles numeric disagreements as `CONFLICTING` under Invariant 4; enforces tri-state applicability (`APPLICABLE`, `NOT_APPLICABLE`, `APPLICABILITY_UNKNOWN`).
- **Gaps:** Evaluators for Rules 4, 5, 25, 26(b), 26(c), 27, 31 need implementation; font-height Rule 7(2) currently produces `UNCERTAIN` because `geometry.py` and `calibration.py` have not yet been placed into `backend/`.

### 3.2 Vision & OCR Pipeline
- **Strengths:** 2152 lines of region-first, orientation-aware OCR. Resolves font/ink conflicts with numeric signatures; distinguishes real ink codes from barcode symbology noise.
- **Gaps:** `pyzbar` is not available in sandbox for decoding detected barcode/QR bounding boxes. OCR variant ranking optimization needed for runtime speedup.

### 3.3 Geometry, Calibration & Measurement
- **Strengths:** Complete and validated in `CLAUDE 4/backend/` with 119 unit and real-photo tests. Pure Python math in `calibration.py` connects reference cards (85.6mm) and known dimensions to pixel-per-mm scales with propagated uncertainty.
- **Gaps:** Not yet copied into canonical `backend/` and wired into `schema.py` and `rule_engine.py` autofill.

### 3.4 Persistence, Auth & Reporting
- **Strengths:** Full schema DDL and persistence layer with `inspection_findings`, evidence JSON serialization, and immutable audit logging. Evidence-backed PDF report generator tested against real PDFs.
- **Gaps:** `config.py` had a top-level hard import `from dotenv import load_dotenv` which failed in minimal environments without python-dotenv; fallback wrapper needed. `dashboard.html` lacked Authorization headers for JWT-secured endpoints.

### 3.5 Frontend
- **Strengths:** `CLAUDE 1` produced a production-grade React app with full TypeScript definitions, token storage, and session workflow.
- **Gaps:** `frontend/dashboard.html` was missing Bearer token authorization, causing 401s when testing against the secured FastAPI backend.

---

## 4. Prioritized Implementation Roadmap

1. **Phase 1: Contract & Dependency Resilience**
   - Make `dotenv` import in `backend/config.py` gracefully optional so core modules and tests run anywhere without environmental failures.
   - Sync `backend/schema.py` with the additive geometry/measurement enums and models from `CLAUDE 4/backend/schema.py` (`MeasurementMode.NOT_OBSERVED`, `PackageShapeHint`, `CalibrationMethod`, `PDPObservationStatus`, `GeometryReadiness`, `PackageGeometry`, `PDPGeometry`, `RectificationResult`, `PhysicalMeasurement`, `GeometryReadinessResult`).

2. **Phase 2: Canonical Geometry & Calibration Integration**
   - Copy `CLAUDE 4/backend/calibration.py` and `CLAUDE 4/backend/geometry.py` to `backend/`.
   - Copy `CLAUDE 4/backend/tests/test_calibration.py` and `test_geometry.py` to `backend/tests/`.
   - Wire `calibration.py` PDP-area and numeral-height measurement into the rule engine and capture session workflows.

3. **Phase 3: Expanded Legal Rule Evaluators**
   - Implement evaluators in `backend/rule_engine.py` for:
     - Rule 4 (Multi-pack declarations)
     - Rule 5 / Second Schedule (Standard pack quantities)
     - Rule 25 (Export repack / India sale treatment)
     - Rule 26(b) (Fast-food exemption)
     - Rule 26(c) (Drug formulation exemption)
     - Rule 27 (Registration reference handling)
     - Rule 31 (Advertisement price/quantity declaration)

4. **Phase 4: Frontend & Auth Hardening**
   - Add JWT token authentication input and session support into `frontend/dashboard.html`.
   - Canonicalize `CLAUDE 1`'s React app under `frontend/` with full build instructions and typed API client integration.

5. **Phase 5: Automated Verification & Documentation**
   - Verify all unit and integration test suites.
   - Update `IMPLEMENTATION_STATUS.md` and `PROJECT_STATE.md`.
